const express = require('express');
//const bodyParser = require('body-parser')
const cors = require('cors')
const app = express();

app.use(cors())
require('../server/config/mongoose.config'); //add this for db


app.use(express.json()) //add this for db
app.use(express.urlencoded({extended: true})) //add this for db
//app.use(bodyParser.urlencoded({ extended:  true}))


const port = 8001;
require('../server/routes/authors.routes')(app);
    
app.listen(port, () => console.log(`Listening on port: ${port}`) );
