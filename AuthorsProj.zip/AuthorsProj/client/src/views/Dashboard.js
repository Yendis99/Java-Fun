import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';


const Dashboard = (props) => {

const [hooty, setHooty] = useState([]);
const [load, setLoad] = useState(false);


var title = document.querySelector('title');
title.innerText = 'Authors';
 
    useEffect(() => {
       
        axios.get('http://localhost:8001/api/author') 
        //return a promise
            .then(res => setHooty(res.data.allauthors))
            setLoad(true)

    
    },[props]);//empty means run once

    if(!load) return "Loading..."; //wait please spinner

    return (
        <>
      

        <div className="top">
          
        <h1 className="title">Favorite Authors</h1>
        <Link className="link" to="/add">Add an authors</Link>
        <h4 className="inst">We have quotes by:</h4>
           
         </div>

        <div className="botton">
        <table  id="authors">
                <tr>
                    <th>Authors</th>
                    <th>Actions available</th>
                
                </tr>
                </table>

            {hooty.map((hooty)=>(//how do you pass the _id value to the edit page?
                <table  id="authors">
                <tr>
                    <td key={hooty._id} > 
                    <p>{hooty.aname}</p>
                
                    </td>
                    <td>
                  
                        <Link className="edit" to={'/edit/' + hooty._id}>Edit</Link>
                        <Link className="delete" to={'/delete/' + hooty._id}>Delete</Link>

                    {/* find out how to implement the links as buttons */}


                       
                      
                    </td>
               </tr>
               </table>
             

            
         


        ))}

        
        </div>
  

        </>
    )
}

export default Dashboard;