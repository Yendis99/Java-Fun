import './App.css';
import { Router } from '@reach/router';
import Dashboard from './views/Dashboard';
import Add from './views/Add';
import Edit from './views/Edit';
import Delete from './views/Delete';
import Success from './views/Success';




function App() {
  return (
    <div className="App">
      <Router>
        <Dashboard path = "/dash" />
        <Add path = "/add" /> 
        <Edit path = "/edit/:id" />
        <Delete path = "/delete/:id" />
        <Success path = "/success" />
      </Router>
      
    </div>
  )
};

export default App;
