import './App.css'; 
import React, { useState } from 'react';
import BoxForm from './Components/BoxForm';
import BoxDisplay from './Components/BoxDisplay'

const boxreq = [];


function App(){
   const[boxreq, setBoxReq] = useState([]);

  const newBoxParams = ( divprams ) => {
  
     setBoxReq([...boxreq,divprams]);

  

   

    console.log(divprams); 
    console.log(boxreq);

 
  


    };



  
  return (

    <>
   
      <BoxForm onNewBox = {  newBoxParams } />
      <BoxDisplay  ray = { boxreq } />
   
    
    </>

  );

}

export default App;
