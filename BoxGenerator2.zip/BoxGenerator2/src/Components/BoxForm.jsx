import React, { useState } from 'react'; 
const onNewBox = [];
const BoxForm = (props) => {
	const [color, setColor] = useState(" ");
	const [height, setHeight] = useState(" ");
	const [width, setWidth] = useState(" ");

	const handleSubmit = (e) => {
		e.preventDefault();
		//what do we do with new box entry?
	const onNewBox = {color, height, width};
		props.onNewBox(onNewBox);
			//console.log(onNewBox);
			setColor("");
	};
	return(
		

		<>
			<h1> Create A Box </h1>
			<form onSubmit={ handleSubmit }>
				
				<div className="colorDiv">
					<label>Color:</label>
						<input type="text" onChange={ (e) => setColor(e.target.value) } value={color} />
					</div>

					<div className="HeightDiv">
					<label>Height:</label>
						<input type="text" onChange={ (e) => setHeight(e.target.value) } value={height} />
					</div>

					<div className="WidthDiv">
					<label>Width:</label>
						<input type="text" onChange={ (e) => setWidth(e.target.value) } value={width} />
					</div>

					<input className="clkr" type="submit" />
					

				</form>
			</>

		);
}

export default BoxForm;