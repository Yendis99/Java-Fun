// import '../App'; 
// import React, { useState, Component } from 'react';

// import BoxDisplay from './Components/BoxDisplay'

 
// class BlockMaker extends Component{
//     // const [block, setBlock] = useState("");
//     constructor(color, height, width){
//         this.color = bxprams.color;
//         this.height = bxprams.height;
//         this.width = bxprams.width;
//     }
 
//     render(){
//         return(
//             <div style={{height:this.height+'px', width:this.width+'px', backgroundColor:this.color, justifyContent:"space-around", margin:"40px"}}></div>
//         )
//     }

   
// }

// export default BlockMaker;
