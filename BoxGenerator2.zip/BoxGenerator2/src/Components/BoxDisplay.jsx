import { render } from '@testing-library/react';
import react, { useState, Component} from 'react';
import '../App.css';


  const bxprams = []; 

const BoxDisplay = (props) => {	
	const [boxes, setBoxes] = useState("");

	
	

		const bxprams = (props.ray);
		let color = bxprams.color;

		

		//console.log(BBoxes);
	
	
	// console.log(bxprams);
	// console.log(props.ray);
	// console.log(props.ray.color);
	// console.log(props.ray.height);
	// console.log(props.ray.width);

	const clearColorFld = (e) => {
		props.setColor("");
	}

	
	return(
		<>
	
	
  {/* <h1 className="greeting">
    Hello, world!
  </h1> */}
  <div style={{height:"1px", width:"1px", backgroundColor:"white", justifyContent:"space-around", margin:"0px"}}></div>

  {/* <div style={{height:bxprams.height+'px', width:bxprams.width+'px', backgroundColor:bxprams.color, justifyContent:"space-around", margin:"0px"}}></div> */}




<div className="frame">
  <ul className="ulst">{
				bxprams.map((item, i) =>
	<li className="lii">  <div key={ i }	style={{backgroundColor:{...item}.color, height:{...item}.height+'px', width:{...item}.width+'px',  justifyContent:"space-around", margin:"10px"}}></div>  </li> )
		}</ul>
		</div>


	






		</>

		);
	
}

export default BoxDisplay;