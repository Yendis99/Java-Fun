import logo from './logo.svg';
import './App.css';

import PersonCardComponent from './components/PersonCardComponent';


  function App() {
    return (
      <div className="App">
        <h1><PersonCardComponent someText={"Doe, Jane"}/></h1>
        <h2><PersonCardComponent someText={"Age: 30"}/></h2>
        <h2><PersonCardComponent someText={"Hair Color: Brown"}/></h2>
        
        <h1><PersonCardComponent someText={"Doe, John"}/></h1>
        <h2><PersonCardComponent someText={"Age: 32"}/></h2>
        <h2> <PersonCardComponent someText={"Hair Color: Black"}/></h2>
        
        <h1><PersonCardComponent someText={"Doe, Sally"}/></h1>
        <h2><PersonCardComponent someText={"Age: 8"}/></h2>
        <h2><PersonCardComponent someText={"Hair Color: Black"}/></h2>
        
        <h1><PersonCardComponent someText={"Doe, Jimmy"}/></h1>
        <h2><PersonCardComponent someText={"Age: 11"}/></h2>
        <h2><PersonCardComponent someText={"Hair Color: Brown"}/></h2>
        
      </div>
    );
  }

export default App;
