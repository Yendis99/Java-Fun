import React, { Component } from 'react';

class PersonCardComponent extends React.Component{
	render(){
		return(
			<div>
				{this.props.someText}
			</div>
		);
	}
}

export default PersonCardComponent;