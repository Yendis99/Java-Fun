import react, { useState } from 'react';

const NavbarDisplay = (props) => {
    return (
    <>
        <div>

            <h1 style={{
                display: "inline",
                height: "100px",
                width: "2100px",
                color: "white",
                backgroundColor: 'DodgerBlue',
                overflow: 'hidden',
    
                float: 'left',
                color: 'White',
                fontsize: '20px',
                textalign: 'center',
                padding: '14px 16px',
                textdecoration: 'none',



            }}>
                { props.name }
                 {/* from NavBarDisplay.js */}

            </h1>


          
        </div>
     


        <br></br>
        
    </>
    )
}

export default NavbarDisplay;