import React, { useState } from 'react';
import NavbarForm from './NavbarForm';
import NavbarDisplay from './NavbarDisplay';

function NavbarApp(props) {
    const [navbarName, setNavbarName] = useState("Enter a name");

    const newNavName = ( newName ) => {
        setNavbarName( newName );
    }

    return(
        <>
            <NavbarDisplay name = { navbarName } />
            <NavbarForm onNewName = { newNavName } />
          
            {/* <p>NB: new nave names and components are managed by NavbarApp.js</p> */}
        </>
    );
}

export default NavbarApp; 