import react, { useState } from 'react';
import navbarApp from './NavbarApp';

const NavbarForm = (props) => {
    const [name, setName] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        //what should we do with info returned?
        props.onNewName( name );
    };

    return(
       
       
        <form onSubmit={ handleSubmit }>
            <h4>Add Your Name to the Navbar</h4>
            {/* <p>NB: this is in the NavbarForm.js</p> */}

            <div>
            <label>Name: </label> 
                 <input type="text" onChange={ (e) => setName(e.target.value) } value={ name }/>
             </div>
             <input type="submit" value="Update Navbar" />
           
        </form>
      
    );
};

export default NavbarForm;