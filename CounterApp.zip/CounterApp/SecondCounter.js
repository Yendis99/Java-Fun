import React, { useState } from 'react';

import Counter from './Counter';

export default () => (
    <Counter
        initialValue={10}
        render={({ count, increment, decrement }) => (
            <>
            <h2>The count is currently {count}!</h2>
            <button onClick={increment}>Increment</button>
            <button onClick={decrement}>Decrement</button>
            </>
        )}
    />
)