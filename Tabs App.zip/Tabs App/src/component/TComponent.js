import '../App.css';
import React from 'react';
import { Router, Link, navigate } from '@reach/router';


const TComponent = (props) => {
  return(
  <h1> Welcome to the TComponent!</h1>
  
  
  );
  }






export default TComponent;


