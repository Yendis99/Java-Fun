import '../App.css';
import App from '../App.js';
import api from '../App.js';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';

import { Router, Link, Navigate, Switch } from '@reach/router';

import './TComponent';

import { Container, Row, Col, Button, Alert, Breadcrumb, Card, Form } from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'

import React, { useState, useEffect, State, Component } from 'react';
import { render } from '@testing-library/react';
import axios from 'axios';



const HomeBox =({pokemons, pop}) => { 


  return (
  
   <>
    


 
  <Tabs>
    <TabList>
      <Tab >Lorem</Tab>
      <Tab >10 Pokemon</Tab>
     
      <Tab>TComponent</Tab>
      
    </TabList>

    <TabPanel >
     
        <b>Lorem</b> (<i>Lorem</i>) <p>ELorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
      </p>
      <p>
        Source:{<a href="https://lipsum.com" target="_blank" > Lorem</a>}
        
      </p>
    </TabPanel>
    <TabPanel>
    <b>10 Pokemon</b> 
    <div> {pokemons.length > 0 && pokemons.map((poke, index)=>{
                return (<div key={index}>{poke.name}</div>)
            })}</div>
      
     
      <p>
        Source:{ <a href="https://pokeapi.co/api/v2/pokemon?offset=10&limit=10" target="_blank"> 10 Pokemons </a> }
        
      </p>
    </TabPanel>
    
    <TabPanel>
      <p>
        <b>TComponent</b> <div>
          <Link to = "/tcomp"  >TComponent</Link>           
        </div>
      </p>
     
    </TabPanel>
   
  </Tabs>


  

    </> 
  
  );
}

export default HomeBox;
