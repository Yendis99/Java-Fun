import './App.css';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
//import Tabs from 'react-bootstrap/Tabs'
//import Tab from 'react-bootstrap/Tab'
// import TabContainer from 'react-bootstrap/TabContainer'
import { Container, Row, Col, Button, Alert, Breadcrumb, Card, Form } from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'
import HomeBox from './component/HomeBox.js';
import React, { useState, useEffect, State, Component } from 'react';
import { render } from '@testing-library/react';
import axios from 'axios';
import { Router, Link, Navigate, Switch } from '@reach/router';
import TComponent from './component/TComponent';



const App = () => { 

  const [poke, setPoke] = useState([]);

  
  const api =() => { 
     axios.get(`https://pokeapi.co/api/v2/pokemon?offset=10&limit=10`)
     .then(response => setPoke(response.data.results))
     console.log("Yep")
     
    }

    api();

  return (
    
   
    
  
      <div className="App">
      <header className="App-header">
      
     
      <HomeBox pokemons={poke} pop = "Some text that needs to be placed" />

      
        <Router>
          <TComponent path="/tcomp" />
        </Router>
      
        
      </header>
    </div>
    

  );
}

export default App;
