package com.srobin.dojosurvey;

import javax.servlet.http.HttpSession;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
//@RestController
public class DojoSurveyIndexController {
	
	@RequestMapping("/")
	public String index(HttpSession session, Model model) {
		System.out.println("root");
		
		return "index.jsp";
				
		}
	
	@RequestMapping(value="info", method=RequestMethod.POST)
	public String getInfo(@RequestParam(value="flname") String flname, @RequestParam(value="dojloc") String dojloc,
			@RequestParam(value="favlang") String favlang, @RequestParam(value="comments") String comments, HttpSession sesh) {
		
		sesh.setAttribute("flname", flname);
		sesh.setAttribute("dojloc", dojloc);
		sesh.setAttribute("favlang", favlang);
		sesh.setAttribute("comments", comments);
	
		System.out.println(flname);
		System.out.println(dojloc);
		System.out.println(favlang);
		System.out.println(comments);
		

	if(flname.length() < 1){
		return "redirect:/throwErr";
	}
		if(dojloc.length() < 1) {
			return "redirect:/throwErr";
		}
			if(favlang.length() < 1) {
				return "redirect:/throwErr";
			} else {
				
			
				return "redirect:/result";
			}
		}
		


	@RequestMapping("/throwErr")
    public String flashMessages(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("error", "Name, location, and fav lang must have info.");
        return "redirect:/";
    }
	
	

	@RequestMapping("/result")
	public String result(HttpSession sesh, Model model) {
		
		
		
		
		
		return "result.jsp";
				
		}
}


