import { useEffect, useState } from 'react';
import Usef from './Usef';
import People from './People';
import Planets from './Planets';
import Starships from './Starships'

const GetSkyApi = (props) => {

 //const [people, setPeople] = useState([]);
 const [sky, setSky] = useState([]);
 const [home, setHome] = useState([{}]);

  useEffect(() => {
    fetch('https://swapi.dev/api/people')
           .then(response => response.json())
           .then(response => setSky(response.results))

    fetch('https://swapi.dev/api/planets/')
           .then(response => response.json())
           .then(response => setHome(response.results))
      
          

  
           
                 
          
    
          
  }, []);

  console.log("skyapi", sky);



  

  return (
      <>


    {/* <Starships data={sky} />
    <Planets data={sky} />
    <People data={sky} /> */}
    <Usef data={sky} hdata={home} />


    </>

  );

}

export default GetSkyApi;
