import './App.css';
import { Redirect, Router, Link } from '@reach/router';
// import { Redirect, BrowserRouter as Router, Link } from 'react-dom';


import 'bootstrap/dist/css/bootstrap.min.css';

import Usef from './Components/Usef';
import Learn from './Components/Learn';
import Circles from './Components/Circles'; 
import GetSkyApi from './Components/GetSkyApi';
import People from './Components/People';
import Planets from './Components/Planets';
import Starships from './Components/Starships';
import MessageBridgeApp from './Components/MessageBridgeApp';
import NavbarApp from './Components/NavbarApp';
import FirstCounter from './Components/FirstCounter';
import SecondCounter from './Components/SecondCounter';
import SampList from './Components/SampList';





function App(props) {
  return (
    <div className="App">
      <Router>
        <Learn path = "/learn" />
       
       
        <Circles path = "/circ" />
       
        <Usef path = "/usef" />
        <GetSkyApi path = "getsky" />

        <People path = "/people/:plug" component={People}/>
        <Planets path = "/planets" />
        <Starships path = "/starships" />

        <MessageBridgeApp path = "/message" />

        <NavbarApp path = "/navbar" />

        <FirstCounter path = "/first" />
        <SecondCounter path = "/second" />

        <SampList path = "/samplist" />

       



        {/* <Edit path = "/update/:id" />  */}
        {/* <Redirect from = "/" to = "/dashpro" />
        <DashPro path = "/dashpro" />
        <EditPro path = "/update/:id" />  */}
      </Router>

      
      
    </div>
  )
};

export default App;
