import React, { useEffect, useState } from 'react';
import Usef from './Usef';
import GetSkyApi from './GetSkyApi';
import Planets from './Planets';


const People = (props) => {
  // const [homeworld, setHomeworld] = useState([{}]);
  const [hme, setHme] = useState(false);
  //const [geo, setGeo] = useState([{}]);
  const [geo, setGeo] = useState(props.hgrab);
  const [numero, SetNumero] = useState(props.n);
const [bio, setBio] = useState(props.grab);
console.log(props.hgrab);
//setGeo(props.hgrab);

  // useEffect(() => {
  //   fetch('https://swapi.dev/api/planets/')
  //          .then(response => response.json())
  //          .then(response => setHomeworld(response.results))
      
          
  // }, []);
  





let N = numero;



console.log(geo);


// console.log(props.grab.[N-1])
// console.log(bio.[N-1].name)
// console.log(bio.[N-1].height)
// console.log(bio.[N-1].hair_color)
// console.log(bio.[N-1].mass)
// console.log(bio.[N-1].eye_color)

  const clickHandler = (e) =>{
    setHme(true);
    return(
     <>
       
      </>
      );
    }


  function refreshPage() {
    window.location.reload(false)
  }


  return(
    <>
      <hr></hr>

      <h1>Name: {bio.[N-1].name}</h1>
      <h1>Height: {bio.[N-1].height}</h1>
      <h1>Hair Color: {bio.[N-1].hair_color}</h1>
      <h1>Weight: {bio.[N-1].mass}</h1>
      <h1>Eye Color: {bio.[N-1].eye_color}</h1>
      <h1>Homeworld: {geo.[N-1].name}</h1>
 
      <br></br>
      <button onClick= {clickHandler} > Click for More Homeworld Details!</button>
      <br></br>
      <br></br>
     

      {hme === false ? 
            
            ''
            
            
            : 
             
         
     
            
            
            <div>  
              <>
              <h1>Climate: {geo.[N-1].climate} </h1>
              <h1>Population: {geo.[N-1].population} </h1>
              <h1>Diameter: {geo.[N-1].diameter} </h1>
              <h1>Gravity: {geo.[N-1].gravity} </h1> 
              </>
            </div>
            
          }

      <br></br>
      <button onClick={refreshPage}>Click to Start New Search!</button>


    </>
    
      

  );

}

export default People;
