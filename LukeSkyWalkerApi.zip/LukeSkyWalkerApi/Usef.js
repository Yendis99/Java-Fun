import React, { useState } from 'react';


import './component.css';
import Planets from './Planets';
import People from './People';
import Starships from './Starships';
// import { findAllByAltText } from '@testing-library/dom';



const Usef = (props) => {

    const [stuff, setStuff] = useState({});
    const [call, setCall] = useState('');
    const [inputs, setInputs] = useState(false);

 

    
 
    const getty = e => {
        setStuff({
        ...stuff,
        [e.target.name]: e.target.value
    
    
    })};


    //You can use this pointers to get spec info - they work - info will tell you people, planet, or starship
    // id wil tell which id has been selected in the dialogue
    console.log("this is real", stuff);
    console.log(stuff.id);
    console.log(stuff.info);
              
             



    const clickHandler = (e) =>{
               e.preventDefault();

                //getting number selected
                let numbr = stuff.id


                //Validation popups for search fields
                if(stuff.info === undefined){
                    
                    alert("Please select people, planet, or starship from the search drop down");
                    return;
                }

                if(stuff.id === undefined){
                    
                    alert("Please enter an id number greater than 0");
                    return;
                }


                //Routing to People, Planets, and Starships components
                if(stuff.info === "People"){
                   

                    if(numbr < 1){

                        alert("These aren't the droids you're looking for!");
                        return;

                    } 
                   
                
                   setCall(<People n = {numbr} grab = {props.data} hgrab = {props.hdata} />);
                 
                
                 
                    
                    } 


                if(stuff.info === "Planets"){
                

                    if(numbr < 1){

                        alert("These aren't the droids you're looking for!")
                        return;
                    } 

                   setCall(<Planets n = {numbr} grab = {props.data} />)

                    }
                    

                if(stuff.info === "Starships"){
                        
                        if(numbr < 1){

                            alert("These aren't the droids you're looking for!")
                            return;
                        } 

                        setCall(<Starships  n = {numbr} grab = {props.data} />)

                        }


                return(        
                  {call}   
                  
                );

      
                }
               

                        
                      


                        //these console have proven that when the components people, planet, and starship are called indi
                        // the call returns the fetched api object correclty NB: there is no signal for this in Usef
                        // However, the selected/filtered data requested for search SHOULD be returned and displayed in Usef
                        // console.log(props.data);   
                        // console.log(props.celest);  
                        // console.log(props.ufo);    
                        
                              
            
                       
console.log(inputs);
console.log(call);
    return(
        <>
        
        {inputs === false ? 
        
        <>

            <div>

            <h1>Luke API Walker</h1><p>1st 10 characters only</p>


                <form>
                
                    <label className="here">
                        Search For: 
                        <input onSelectCapture={getty} type='text' name='info' list='htmlFor' initial-Value="People"/>
                            <datalist id='htmlFor'>
                                <option value="People" />
                                <option value="Planets"/>
                                <option value="Starships"/>
                            
                            </datalist>
                
                        
                        <input onChange={getty} type='number' name='id' />
                        
                    </label>
                        <input onClick={clickHandler} type="submit"  value= 'Search' />

                    
                </form>


            </div>



        </> : ''} 
      
        <> 
          
            {call}

           


          
        </>

        </>

    );
   

};
    


  
export default Usef;
