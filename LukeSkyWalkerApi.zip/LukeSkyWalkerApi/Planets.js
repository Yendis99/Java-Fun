import { useEffect, useState } from 'react';
import Usef from './Usef';
import GetSkyApi from './GetSkyApi';

const Planets = props => {

 const [planets, setPlanets] = useState([{}]);
 const [pnumero, SetPnumero] = useState(props.n);

 let N = pnumero;

 

  useEffect(() => {
    fetch('https://swapi.dev/api/planets/')
           .then(response => response.json())
           .then(response => setPlanets(response.results))
      
          
  }, []);

  //Test: this will show the planets obj in the console
  console.log("from planets", planets);
  // console.log("name", planets.[0].name)
  // console.log("climate", planets.[0].climate)
  // console.log("population", planets.[0].population)
  // console.log("size", planets.[0].diameter)



  function refreshPage() {
    N=0;
    window.location.reload(false);
  }



  return (
      <>

    <hr></hr>
    {/* <div>"Planets Says Hello"</div>
    <h1>N = {N}</h1> */}

       
   

    {planets.[N-1] === undefined ? 
          
      ''
      
      : 
      
      <>
      <h1>Name: {planets.[N-1].name} </h1>  
      <h1>Climate: {planets.[N-1].climate} </h1>
      <h1>Population: {planets.[N-1].population} </h1>
      <h1>Diameter: {planets.[N-1].diameter} </h1>
      <h1>Gravity: {planets.[N-1].gravity} </h1>
      
      
    </> 
    }

  <div>
      <button onClick={refreshPage}>Click to Start New Search!</button>
  </div>


      {/* {planets.length > 0 && planets.map((celest, index)=>{
                    return (<div key={index}   > 
                        
                            {index} {celest.name}

                            </div>
                            
                    )
                   
                  })} */}

    {/* < Usef bio={planets} /> */}

    </>

  );

}

export default Planets;