import { useEffect, useState } from 'react';
import Usef from './Usef';

const Starships = (props) => {
   


 const [ships, setShips] = useState([{}]);

 const [snumero, SetSnumero] = useState(props.n);

 let N = snumero;

//  alert("made it to Starships")

  useEffect(() => {
    fetch('https://swapi.dev/api/starships/')
           .then(response => response.json())
           .then(response => setShips(response.results))
      
  }, []);



  //Test: this will show the ships obj in the console
  console.log("from starships", ships);

  console.log(ships)

  //console.log("name", ships.[N-1].name)
  // console.log("manufacturer", ships.[0].manufacturer)
  // console.log("speed", ships.[0].max_atmosphering_speed)
  // console.log("hyoerdrive rating", ships.[0].hyperdrive_rating)
  //  console.log("look see", props);


  function refreshPage() {
        window.location.reload(false);
  }


  return(
      <>

      <hr></hr>
      {/* <h1>"Starships Says Hello"</h1>
      <h1>N = {N}</h1> */}

      

      {ships.[N-1] === undefined ? 
         
      ''
      
      : 


      <>
      <h1>Name: {ships.[N-1].name} </h1>  
      <h1>Manufacturer: {ships.[N-1].manufacturer} </h1>
      <h1>Max Atmos Speed: {ships.[N-1].max_atmosphering_speed} </h1>
      <h1>Hyperdrive rating: {ships.[N-1].hyperdrive_rating} </h1>
      <h1>Cost in Credits: {ships.[N-1].cost_in_credits} </h1>
      </>
       
      }


              
    <div>
      <button onClick={refreshPage}>Click to Start New Search!</button>
    </div>




       {/* <span>{props.nme}</span>
      
        {ships.length > 0 && ships.map((transport, index)=>{
                    return (<div key={index}   > 
                        
                            {index} {transport.name}

                            </div>
                            
                    )
                   
                  })}

                 <div>{transport.[id].name</div>
         
                   */}
                     
        
        
     

    </>

  );

}

export default Starships;