public interface Ringable {
    // public abstract void displayInfo();
    // public abstract String ring();
    // public abstract String unlock();
}
