public class PhoneTest{
	public static void main(String[] args){
		Galaxy s7 = new Galaxy("S7", 99, "Verizon", "Ding Dong!");
		IPhone i9 = new IPhone("iX", 100, "TMobile", "Ding,Ding,Ding!");

		s7.displayInfo();
		System.out.println(s7.ring());
		System.out.println(s7.unlock());

		i9.displayInfo();
		System.out.println(i9.ring());
		System.out.println(i9.unlock());
	}
}