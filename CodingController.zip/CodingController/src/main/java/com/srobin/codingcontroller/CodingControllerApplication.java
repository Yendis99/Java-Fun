package com.srobin.codingcontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@SpringBootApplication
public class CodingControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingControllerApplication.class, args);
	}
	@RequestMapping("/coding")
	public String dojo() {
		return "Hello Coding Dojo!";
	}
	@RequestMapping("/coding/python")
	public String python() {
		return "Python/Django was awesome!";
	}
	@RequestMapping("/coding/java")
	public String java() {
		return "Java/Spring is better!";
	}
	
	@RequestMapping("/{loc}")
	public String getPathVariable(@PathVariable("loc") String loc) {
		System.out.println(loc);
		String x = "dojo";
		System.out.println(x);
		if(loc.equals("dojo")) {
			
			return "The dojo is awsome!";
		}
		if(loc.equals("burbank-dojo")) {
			return "Burbank dojo is located in Southern California";
		}
		if(loc.equals("san-jose")) {
			return "SJ dojo is the headquarters";
		}
		else {
			return "not found";
		}
	}
}

	


