import logo from './logo.svg';
import './App.css';
import NMonday from './Components/NMonday';
import UseEffect from './Components/UseEffect';
import PokeApi from './Components/PokeApi';
import React, { useState, useEffect, State, Component } from 'react';
import { render } from '@testing-library/react';

function App() {
  const [poke, setPoke] = useState([]);
  
    const api =() => { 
      fetch('https://pokeapi.co/api/v2/pokemon?offset=807&limit=807')
            .then(response => response.json())
            .then(response => setPoke(response.results))
    }
  return(
    <>
      

    <div className="App">
  
    
      <button onClick={ () => api() }>Get More Pokemon</button>
      
        <PokeApi pokemons={poke} myProp = "Sidney" />
      
      
    

    
   
    </div>
   
    


  </>
  );
  
}

export default App;
