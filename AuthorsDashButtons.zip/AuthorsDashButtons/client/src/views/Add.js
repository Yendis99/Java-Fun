import { useState } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

function Add (props) {

    const [aname, setAname] = useState(null);
    const [sub, setSub] = useState(null)
    
    var title = document.querySelector('title');
    title.innerText = 'Authors';
    
    const onSubmitHandler = e => {
        //prevent default behavior of the submit
        e.preventDefault();

        if(sub == "submit" && aname != undefined){
        //make a post request to create a new Author
        axios.post('http://localhost:8001/api/author',{
           aname         
        })
            // .then(res=>console.log(res))
            .then(res => navigate("/dash"))
            .catch(err=>console.log(err))
        
        } else {
            
            navigate("/dash")

        }
    }
    
    return (
        <>

        <div className="top">
        <h1 className="title">Favorite Authors</h1>

        <Link className="home" to="/dash">Home</Link>

        <h4 className="inst">Add a new author:</h4>

        </div>

        <div className="bottom">

        <form onSubmit={onSubmitHandler}>
            <div className="ini">
            <p>
                <label>Name: </label>

                <br></br>

                <input type="text" onChange = {(e)=>{setAname(e.target.value)}}/>
            </p>
            </div>

            <button className="canx" type="cancel" value = "cancel" onClick = {(e)=>{setSub("cancel")}} >Cancel</button>
        
        <button className="sub" type="submit" value="submit" onClick = {(e)=>{setSub("submit")}}>Submit</button>

        </form>
        </div>
   

        

      
        
  
        
        </>
    )
}

export default Add;