import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';
import Success from '../views/Success';

const Delete = (props) => {
       const {id} = props;

    var title = document.querySelector('title');
    title.innerText = 'Authors';
    
         axios.delete('http://localhost:8001/api/author/' + id + '/delete')
      

      return(
       <>
             <Success />
       </>
      )
    }

    export default Delete;

