const routesCtl = require('../controllers/authors.controller');
module.exports = (app) => {
    app.get("/api/author", routesCtl.getAll);
    app.post("/api/author", routesCtl.createAuth);
    app.get("/api/author/:id/item", routesCtl.getItem);
    app.put("/api/author/:id/upd", routesCtl.updateItem);
    app.delete("/api/author/:id/delete", routesCtl.deleteItem);
}