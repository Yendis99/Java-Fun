const Auth = require('../models/authors.model');

//CRUD
//Get all Authors
module.exports.getAll = (req, res) => { console.log("hello All")
    Auth.find()
        .then(allauthors => res.json({allauthors: allauthors}))
        .catch(err => res.json({error: err}));

}


//Add Authors
module.exports.createAuth = (req, res) => { console.log("hello create")
    Auth.create(req.body)
        .then(newauth => res.json({newauth: newauth}))
        .catch(err => res.json({error:err}));

}


// Get individual Author
module.exports.getItem = (req, res) => {console.log("Hello findOne")
    Auth.findOne({ _id: req.params.id })
        .then(getitem => res.json({ getitem: getitem }))
        .catch(err => res.json({ error: err }));
}

// Update an Author
//module.exports.updateItem = (req, res) => {console.log("hello update")


//     Auth.updateOne(
//    // Auth.findByIdAndUpdate(
//         req.params.id,
//         req.body, //This is data sent over with/from the request
//         {
//         // new: true,
//         // runValidators: true 

//          })
//          //.then(console.log(req.body))
//         .then(updateitem => res.json({ updateitem: updateitem}))
//         .catch(console.log(req.body))
//         .catch(console.log(req.params.id))
//         // .catch(err => res.status(400).json({ message: "Something went wrong during update", error: err}));
//         .catch(err => res.json({ message: "Something went wrong during update", error: err}));
// }
module.exports.updateItem = (req, res) => {console.log("Hello Update")
    Auth.updateOne({ _id: req.params.id }, req.body, { new: true })
        .then(updateitem => res.json({ updateitem: updateitem}))
        .catch(console.log(req.body))
        .catch(err => res.json({ message: "Something went wrong during update", error: err}));
   
}

// Delete an Author
module.exports.deleteItem = (req, res) => {console.log("hello delete")
    Auth.deleteOne({ _id: req.params.id })
        .then(result => res.json({ result: result }))
        .catch(err => res.json({ message: "Something went wrong during delete", error: err }));
}
