const mongoose = require('mongoose');
mongoose.connect("mongodb://localhost/Author",{
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false
    
})
 .then(() => console.log('connected'))
 .catch(err => console.log("error occured" ,err))