import './App.css';
import React from 'react';
import { Router } from '@reach/router';
import HelloColorComponent from './Components/HelloColorComponent';
import NumberComponent from './Components/NumberComponent';
import HomeComponent from './Components/HomeComponent';


const App = (props) => {
  return (

    <div className="App">
      <Router>
      <HomeComponent path = "/home" />
      <NumberComponent path = "/:id" /> 
      <HelloColorComponent path = "hello/:txtclr/:bkclr" />
      </Router>
    </div>
  );
}

export default App;
