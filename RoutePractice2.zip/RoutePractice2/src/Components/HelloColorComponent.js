import '../App.css';
import React from 'react';
//import { Router, Link, navigate } from '@reach/router';

const HelloColorComponent = (props) => {
    return(
    <div>   
    <h1  style={{background:props.bkclr}} ><span style={{color:props.txtclr}}> Welcome Some Color</span>  </h1>
    </div> 
    
    
    );
    }


export default HelloColorComponent;