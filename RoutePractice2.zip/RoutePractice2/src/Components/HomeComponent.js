import '../App.css';
import React from 'react';


const HomeComponent = (props) => {
    return(
    <h1> Welcome </h1>
    
    
    );
    }


export default HomeComponent;