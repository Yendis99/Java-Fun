import '../App.css';
import React from 'react';
// import { Router, Redirect } from '@reach/router';


const HelloComponent = (props) => {
    return(
    <h1> Hello the word is: {props.id} </h1>
       
    );
}

export default HelloComponent;