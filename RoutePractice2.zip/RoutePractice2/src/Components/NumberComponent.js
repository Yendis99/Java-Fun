import '../App.css';
import { React } from 'react';


const NumberComponent = (props) => {

   
   
            
            if(isNaN(+props.id)===true){ 
                return( <h1> Hello the word is: {props.id} </h1>);
             } else { 
                return( <h1> The number is: {props.id} </h1>);
             }
        
            }

     


export default NumberComponent;