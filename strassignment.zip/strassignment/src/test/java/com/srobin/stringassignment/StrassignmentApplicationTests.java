package com.srobin.stringassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrassignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
