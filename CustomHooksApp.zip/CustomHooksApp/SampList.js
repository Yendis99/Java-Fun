import React, { useState } from 'react';

import UListy from './UListy';

export default (props) => {
    const [val, setVal] = useState('');
    const[nadd, setNadd] = useState('');
    const { list, add } = UListy(['first', 'second']);

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(val);

         add(val);
        //  console.log(add);
        setVal('');
      
    }

 console.log(props.list);

    return (
        <>
           

           <div>
         { list.map(( item, index ) => {
             return( <p key={index}>
                     {item} </p> )
         })}
         {/* {console.log(list)} */}
        </div>

            <input
                onChange={ (e) => setVal(e.target.value)}
                value={val}
            />
            <button onClick={handleSubmit}>Add</button>



        

        </>
    );
}; 

