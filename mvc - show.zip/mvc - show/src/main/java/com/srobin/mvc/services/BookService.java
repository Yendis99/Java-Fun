package com.srobin.mvc.services;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.srobin.mvc.models.Book;
import com.srobin.mvc.repositories.BookRepository;

@Service
public class BookService {

		private final BookRepository bookRepository;
		
		public BookService(BookRepository bookRepository) {
			this.bookRepository = bookRepository;
		}
		 // returns all the books 
	    public List<Book> allBooks() {
	        return bookRepository.findAll();
	    }
	    // creates a book
	    public Book createBook(Book b) {
	        return bookRepository.save(b);
	    }
	    // retrieves a book
	    public Book findBook(Long id) {
	        Optional<Book> optionalBook = bookRepository.findById(id);
	        if(optionalBook.isPresent()) {
	            return optionalBook.get();
	        } else {
	            return null;
	        }
	    }
	        
        public Book updateBook(Long id, String title, String description, String language, Integer numberOfPages) {    
        	Book b = this.findBook(id);
        	b.setTitle(title);
        	b.setDescription(description);
        	b.setLanguage(language);
        	b.setNumberOfPages(numberOfPages);
        	return bookRepository.save(b);
	    }
        
      
        public Book destro(Long id){
        bookRepository.deleteById(id);
        return null;
        }
     
        public Integer index(HttpSession session, Model model){ 
            session.setAttribute("count", 0);
            Integer count = (Integer) session.getAttribute("count");
            return count;
        }
	    
	    
	 }

        

