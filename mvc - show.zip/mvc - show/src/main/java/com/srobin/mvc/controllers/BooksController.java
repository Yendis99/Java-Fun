package com.srobin.mvc.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.srobin.mvc.models.Book;
import com.srobin.mvc.services.BookService;
import java.util.*;




//List of all books
@Controller
public class BooksController {
    private final BookService bookService;
    
    public BooksController(BookService bookService) {
        this.bookService = bookService;
    }
    
    @RequestMapping("/books")
    public String index(Model model) {
        List<Book> books = bookService.allBooks();
        model.addAttribute("books", books);
    //    System.out.println(books);
        return "/books/index.jsp";
    }
    
  //Create a book Form   
    @RequestMapping("/books/new")
    public String newBook(@Valid @ModelAttribute("book") Book book, BindingResult result) {
        return "/books/new.jsp";
    }
    
 
    @RequestMapping(value="/books", method=RequestMethod.POST) 
    public String create(@Valid @ModelAttribute("book") Book book, BindingResult result) {
        if (result.hasErrors()) {
       
            return "/books/new.jsp";
        } else {
            bookService.createBook(book);
            return "redirect:/books";
        }
	}
    
//Show a Single Book's info 
    @RequestMapping("/books/show/{id}")
    public String show(@PathVariable("id") Long id, Model model) {
    List<Book> books = bookService.allBooks();
    System.out.println(books);
    Book book = bookService.findBook(id);
    model.addAttribute("book", book);
    System.out.println(book);
    return "/books/show.jsp";
   
    }
  
  }



//@RequestMapping("/books/{id}")
//public Book showy(@PathVariable("id") Long id) {
//    Book book = bookService.findBook(id);
//    return book;
//}
    
    
    
    
    
//    @RequestMapping("/books")
//    public String index(HttpSession sesh, Model model) {
//        List<Book> books = bookService.allBooks();
//       
//        
//        sesh.setAttribute("books", books);
//        
//        
//        model.addAttribute("books", books);
//		
//        
//        return "/books/index.jsp";
//    }
//}


//	public List<Book> index(){
//		return bookService.allBooks();
//		
//	}
//}