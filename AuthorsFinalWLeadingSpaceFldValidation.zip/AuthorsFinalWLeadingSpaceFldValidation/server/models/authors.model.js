// const mongoose = require('mongoose');

// const AuthSchema = new mongoose.Schema({
// authName:{type: String}
// },
//     {timestamps: true});

// module.exports.Auth = mongoose.model("Auth", AuthSchema);

// required: [true, "Authors first and last name is requred"],
// minlength: [3 , "The Authors name must be at least 3 characters long"]
//abobe did not seem to be working correctly - added the following


const mongoose = require('mongoose');
const AuthSchema = new mongoose.Schema({
    aname:{
        type:String,
        minlength: [
            2,
            'The Authors name must be at least 2 characters.'
        ],
    }
 },
    { timestamps: true});

//const Auth = mongoose.model('Auth', AuthSchema); <- this line did not work caused undefined errors

//module.exports = Auth; <- this line did not work caused undefined errors

//the line bolow fixed undefined errors: ->
// module.exports.Auth = mongoose.model('Auth', AuthSchema);

const Auth = mongoose.model('Auth', AuthSchema);

module.exports = Auth;