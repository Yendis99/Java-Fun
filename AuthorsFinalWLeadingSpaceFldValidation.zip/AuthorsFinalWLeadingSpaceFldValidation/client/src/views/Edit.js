import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

const Edit = (props) => {
       const {id} = props;

    const [oname, setOname] = useState(props.aname)
    const [edname, setEdname] = useState(null);
    const [go, setGo] = useState(false);
    const [sub, setSub] = useState(null)

    var title = document.querySelector('title');
    title.innerText = 'Authors';
        
    useEffect(() => {
 
      axios.get('http://localhost:8001/api/author/'  + id + '/item')
          .then(res => {
              setEdname(res.data.getitem.aname);
     
          })
  
  },[go])
console.log(sub)


    const onSubmitHandler = e => {
        setGo(true)

        e.preventDefault();
      
       var ed = /^\s+|\s+$/ //this works to identify but does not strip the leading space

       if(ed.test(edname) === false){ 

       alert("Thank you")
       console.log(edname)

        axios.put('http://localhost:8001/api/author/' + id + '/upd',{
          aname : edname,
           
        })
           
            .then(res => navigate("/dash"))
            .catch(err=>console.log(err))
        
    } else {
        
        alert("Leading spaces not allowed")
       // console.log(oname)  


        axios.put('http://localhost:8001/api/author/' + id + '/upd',{
          aname :   oname,
           
        })
            .then(res => navigate("/dash"))
            .catch(err=>console.log(err))
   

    }   
    
    navigate("/dash")

   }
    

    return (
        <>

         <div className="top">

            <h1 className="title">Favorite Authors</h1>
            
            <Link className="home" to="/dash">Home</Link>

            <h4 className="inst">Edit this Author:</h4>            

        </div>


        <div className="bottom">

            <form onSubmit={onSubmitHandler} >
           
            <p>
                <label>Name: </label>
        
                <input type="text" value = {edname} onChange = {(e)=>{setEdname(e.target.value)}}/>
            </p>
            
            <button className="canx" type="cancel" value = "cancel" onClick = {(e)=>{setSub("cancel")}} >Cancel</button>
        
            <button className="sub" type="submit" value="submit" onClick = {(e)=>{setSub("submit")}}>Submit</button>
            
        </form>
  
       

        </div>
       
  
        
        </>
    )
}

export default Edit;