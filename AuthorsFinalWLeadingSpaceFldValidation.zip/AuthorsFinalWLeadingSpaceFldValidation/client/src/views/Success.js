import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

function Success (props) {
    return(
        <>
        <h2>Author successfully been deleted!</h2>
        <Link to="/dash" >Home</Link>
        </>
    )
}

export default Success;