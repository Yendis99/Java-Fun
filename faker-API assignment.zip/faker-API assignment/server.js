const express = require("express");
const faker = require("faker");
const app = express();

app.use( express.json(), express.urlencoded({ extended: true }), express.Router() );

const server = app.listen(8000, () =>
  console.log(`Server is locked and loaded on port ${server.address().port}!`)
);

app.get("/api", (req, res) => {
  res.json({ message: "Hello World" });
});

app.get("/api/1", (req, res) => {
  res.send("Our express api server is now sending this over to the browser");
});

    app.get("/api/users/new", (req, res) => {
    class User {
      constructor(){
        this._id = faker.random.number();
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.phoneNumber = faker.phone.phoneNumber();
        this.email = faker.internet.email();
        this.password = faker.internet.password();
      }
    }
    
     res.json(console.log(new User())); 
  })


    app.get("/api/companies/new", (req, res) => {
      class Company{
        constructor(){
          this._id = faker.random.number();
          this.name = faker.company.companyName();
          this.address = faker.address.streetAddress();
          this.city = faker.address.city();
          this.state = faker.address.state();
          this.zipCode = faker.address.zipCodeByState();
          this.country = faker.address.country();

        }
    }
        res.json(console.log(new Company()))
      })
  



  app.get("/api/users/company", (req, res) => {
    class User {
      constructor(){
        this._id = faker.random.number();
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.phoneNumber = faker.phone.phoneNumber();
        this.email = faker.internet.email();
        this.password = faker.internet.password();
      }
    }
    
     res.json(console.log(new User())); 
  


    
      class Company{
        constructor(){
          this._id = faker.random.number();
          this.name = faker.company.companyName();
          this.address = faker.address.streetAddress();
          this.city = faker.address.city();
          this.state = faker.address.state();
          this.zipCode = faker.address.zipCodeByState();
          this.country = faker.address.country();

        }
    }
        res.json(console.log(new Company()));
    
  });




