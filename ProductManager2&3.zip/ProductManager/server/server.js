const express = require('express');
require('./config/mongoose.config');
const pmanRoutes = require('./routes/pman.routes');

const cors = require('cors');
const app = express();
app.use(express.json());

app.use(cors());

pmanRoutes(app);





app.listen(8000, () => console.log("Hello, listening on 8000"));