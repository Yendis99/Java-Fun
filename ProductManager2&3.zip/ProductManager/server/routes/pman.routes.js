const routesCtl = require('../controllers/pman.controller');
module.exports = (app) => {
    app.get("/api/products", routesCtl.getAllProducts);
    app.post("/api/products", routesCtl.createProducts);
    app.get("/api/products/:id/item", routesCtl.getItem);
    app.put("/api/products/:id/update", routesCtl.updateItem);
    app.delete("/api/products/:id/delete", routesCtl.deleteItem);
}
