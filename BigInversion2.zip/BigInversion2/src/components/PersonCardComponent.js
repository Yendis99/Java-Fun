import React, { Component } from 'react';

function PersonCardComponents(){




	function clickHandler(){
		console.log("button has been clicked")
	}
	return(
		<div className="container">
			<div className="p1">
				
				{/*<button onClick={ clickHandler }>Cick</button>*/}
			</div>
			<div className="p2">
			
				{/*<button onClick={ clickHandler }>Cick</button>*/}
			</div>
		</div>
	)
}

export default PersonCardComponents;