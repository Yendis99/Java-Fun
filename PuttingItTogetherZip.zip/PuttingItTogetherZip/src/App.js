import React, { Component } from 'react';
import './App.css';
import PersonCardComponent from './components/PersonCardComponent';
import ButtonClickClass from './components/ButtonClickClass';


		
 class App extends Component{



   render(){
     return(
       <div className="App">
       		
      
      	<h2><ButtonClickClass /></h2>

      </div>
    
       )
   }
 }   
  
 export default App; 
       
   
   
  

