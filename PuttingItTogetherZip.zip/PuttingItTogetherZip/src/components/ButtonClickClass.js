//This component has increase and
//decrease buttons that change a number displayed on the page

import React, { Component } from 'react';
import PersonCardComponent from './PersonCardComponent';

let age = 0;
let i = 32;
let j = 40;
class ButtonClickClass extends Component{

  
  constructor(props)  {
         super(props);
         
         
     
     this.state={
      messagei:"Age: "+ i, messagej:"Age: " +j, messagef:"Age: " + {props:age}
     
     }

   }
   
  

  clickHandler1(){ 
     i+=1;
    console.log(i);
    this.setState({ messagei:"Age: " + i });
   
  }


  clickHandler2(){  
    i-=1;
    console.log(i);
    this.setState({ messagei:"Age: " + i });
   
  }

   clickHandler3(){     
    j+=1;
    console.log(j);
    this.setState({ messagej:"Age: " + j });
   
  }


  clickHandler4(){    
    j-=1;
    console.log(j);
    this.setState({ messagej:"Age: " + j });
   
  }

   
  render(){
    return(
      <div>
        
          {/*<button onClick={ this.clickHandler.bind(this) } >Click Me 2</button> //use either*/}
            <h1>Suzanne, Que</h1>
            <h2>Hair Color: brown</h2>
            <div>{this.state.messagei}</div>
          <button onClick={() => this.clickHandler1()}>Increase Age</button>
          <button onClick={() => this.clickHandler2()}>Decrease Age</button>  



            <h1>John, Que</h1>
            <h2>Hair Color: brown</h2>
            <div>{this.state.messagej}</div>
          <button onClick={() => this.clickHandler3()}>Increase Age</button>
          <button onClick={() => this.clickHandler4()}>Decrease Age</button>  


          {/* <div>{this.state.messagef}  </div> */}
           
           
        
          
      </div>
      )
 
  }
  

}

export default ButtonClickClass;