import './App.css';
import { Router } from '@reach/router';
import Dash from './views/Dash';
import Edit from './views/Edit';



function App() {
  return (
    <div className="App">
      <Router>
        <Dash path = "/dash" />
        <Edit path = "/update/:id" /> 
      </Router>
      
    </div>
  )
};

export default App;
