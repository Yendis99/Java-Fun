import { useState } from 'react';

function AddProducts(){
    return(
        <div> Hello from Add! </div>
    );
}


export default Add;