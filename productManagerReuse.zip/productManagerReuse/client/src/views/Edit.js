import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';



const Edit = (props) => {
    const {id} = props;
      const[_id, set_Id] = useState(null);
      const [title, setTitle] = useState(null); 
      const [price, setPrice] = useState(null);
      const[desc, setDesc] = useState(null);

      useEffect(() => {
        axios.get('http://localhost:8000/api/products/'  + id + '/item')
            .then(res => {
                setTitle(res.data.getitem.title);
                setPrice(res.data.getitem.price);
                setDesc(res.data.getitem.desc);
                setTtle(res.data.getitem.title);
                setPrce(res.data.getitem.price);
                setDsc(res.data.getitem.desc);
            })
    
    },[])
   



      
    const onSubmitHandler = e => {
        e.preventDefault();
        axios.put('http://localhost:8000/api/products/' + id + '/update',{
            title,
            price,
            desc
        })
            .then(window.location.reload())
            .catch(err=>console.log(err))
      
    }

    const onClickHandler = e => {
        e.preventDefault();
        axios.delete('http://localhost:8000/api/products/' + id + '/delete')
            .then(res => navigate("/dash"))
            .catch(err=>console.log(err));
      
    }

      
      const [ttle, setTtle] = useState(null); 
      const [prce, setPrce] = useState(null);
      const[dsc, setDsc] = useState(null);

    return (
                <>
  
    
        <h1>Update Product</h1>
        <form onSubmit={onSubmitHandler} >
            <div className="ini">
            <p>
                <label></label>
                <input type ="hidden" name="_id" value={_id} onChange = {(e)=>{set_Id(e.target.value)}} />
            </p>    
            <p>
                <label>Title: </label>
                <input type="text" name="title" value= {title} onChange = {(e)=>{setTitle(e.target.value)}}/>
            </p>
            </div>
            <div className="ini">
            <p>  
                <label>Price: </label>
                <input type="decimal" name="price" value= {price} onChange = {(e)=>{setPrice(e.target.value)}}/>
            </p> 
            </div>
            <div className="ini">
            <p>
                <label>Desc.: </label>
                <input type="text"  name="desc" value= {desc} onChange = {(e)=>{setDesc(e.target.value)}}/>
            </p>
            </div>
            <button type="submit">Update Product </button>
             
        </form>

        <div>
         <hr />
        
       
        <h1>Product</h1>  
    
            <h2>Title: {ttle} </h2>
            <h2>Price: {prce}</h2>
            <h2>Desc: { dsc}</h2>
            <br/>
            <Link to="/dash">Back to - Product Dashbaord</Link>

        </div>

        <form onSubmit={onClickHandler} >
            <div className="ini">
            <p>
                <label></label>
                <input type ="hidden" name="delete" value={_id} />
            </p>    
             <button type="submit">Delete Product </button>
             </div>
        </form>
        
        </>
    )
}

export default Edit;