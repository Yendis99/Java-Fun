import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';


function Dash (props) {

    const [prod, setProd] = useState([]);
      //keep track of what is being typed via useState hook
      const [title, setTitle] = useState(null); 
      const [price, setPrice] = useState(null);
      const[desc, setDesc] = useState(null);
      //handler when the form is submitted

    
    const onSubmitHandler = e => {
        //prevent default behavior of the submit
     //   e.preventDefault(); - STOPPED THE PAGE REFRESH, SO I REMOVED IT TO ALLOW THE PAGE TO REFRESH WITH NEWLY ADDED ITEM
        //make a post request to create a new product
        axios.post('http://localhost:8000/api/products',{
            title,
            price,
            desc
        })
            .then(res=>console.log(res))
            .catch(err=>console.log(err))
         //   window.location.reload(false); - FORCED THE PAGE REFRESH - NOT NEEDED AFTRE REMOVING e.prevent default() script
          
    }

    useEffect(() => {
        axios.get('http://localhost:8000/api/products') 
        //return a promise
            .then(res => setProd(res.data.allproducts))
        
    
    },[]);//empty means run once

    if(prod === null) return 'Loading...'; //wait please spinner

    console.log(prod)
     //console.log(props.allproducts)

    return (
        <>
        <h1>Product Manager</h1>
        <form onSubmit={onSubmitHandler}>
            <div className="ini">
            <p>
                <label>Title: </label>
                <input type="text" onChange = {(e)=>{setTitle(e.target.value)}}/>
            </p>
            </div>
            <div className="ini">
            <p>  
                <label>Price: </label>
                <input type="decimal" onChange = {(e)=>{setPrice(e.target.value)}}/>
            </p> 
            </div>
            <div className="ini">
            <p>
                <label>Desc.: </label>
                <input type="text" onChange = {(e)=>{setDesc(e.target.value)}}/>
            </p>
            </div>
            <button type="submit">Add Product</button>
        </form>

        <div>
        <hr />
        <h1>All Products</h1>
        <p>Click on any product below to Edit;</p>
        {prod.map((prod)=>(//how do you pass the _id value to the edit page?
            <div key={prod._id} > 
                <Link to = {'/update/' + prod._id} > <p>{prod._id}{prod.title}</p></Link>
            </div>

        ))}

        {/* <Link to="/edit">Edit Product</Link> */}
        </div>
  
        
        </>
    )
}

export default Dash;