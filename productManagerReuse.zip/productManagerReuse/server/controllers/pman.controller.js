const Product = require('../models/pman.model');

//CRUD
//Get all products
module.exports.getAllProducts = (req, res) => { console.log("hello getAll")
    Product.find()
        .then(allproducts => res.json({allproducts: allproducts}))
        .catch(err => res.json({error: err}));

}

//Add a product
module.exports.createProducts = (req, res) => {console.log("Hello create")
    Product.create(req.body)
        .then(newproduct => res.json({newproduct: newproduct}))
        .catch(err => res.json({error:err}));

}

// Get individual Product
module.exports.getItem = (req, res) => {console.log("hello getItem")
    Product.findOne({ _id: req.params.id })
         .then(getitem => res.json({ getitem: getitem }))
        .catch(err => res.json({ error: err }));
}

// Update Product
module.exports.updateItem = (req, res) => {console.log("hello update")
    Product.updateOne({ _id: req.params.id }, req.body, { new: true })
        .then(updateitem => res.json({ updateitem: updateitem}))
        .catch(console.log(req.body))
        .catch(err => res.json({ message: "Something went wrong during update", error: err}));
};

// Delete Product
module.exports.deleteItem = (req, res) => {console.log("hello delete")
    Product.deleteOne({ _id: req.params.id })
        .then(result => res.json({ result: result }))
        .catch(err => res.json({ message: "Something went wrong during delete", error: err }));
};
