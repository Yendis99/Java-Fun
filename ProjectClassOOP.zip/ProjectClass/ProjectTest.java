public class ProjectTest{
   public static void main(String[] arg){
      Project p = new Project();

      String projectZero = p.Project();
      String projectWithName = p.Project("Sid");
      String projectWithNameDesc = p.Project("Sid", "Big New Idea");
      System.out.println(projectZero);

      Project r= new Project();
      Object raybansZero = r.raybans();
      
 

      }
     
   }
