import java.util.ArrayList;
import java.util.Collections;
import java.lang.Object;
import java.util.Scanner;
import java.lang.Iterable;
import java.lang.reflect.Array;

public class Project{
	private String name;
	private String desc;

public String name(){
	return name;
}

public void setName(String name){
	name = name;
}

public String desc(){
	return desc;
}
public void setDesc(String desc){
	desc = desc;
}

// public String displayPlanner(){
// 	return desc;
// }
public void SetdisplayPlanner(String desc){
	desc = desc;
}
	




	public String Project(){
		return projOutput("non-requested");

		}
	public String Project(String name){
			return projOutput(name);

		}
	public String Project(String name, String desc){
			return projOutput(name + " " + desc);

		}

	private String projOutput(String projectToOutput){
		return "Your projects info: " + projectToOutput + " Thank you.";
	}

 	public Object raybans(){
 		
  		return displayPlanner();
   }


	//Planner
   int j = 1;
	int y = 0;
	Object z = 0;
	int i = 0;
	
	protected Object displayPlanner(){
	ArrayList<Object> plann = new ArrayList<Object>();
	plann.add("project:");
	plann.add("This is the description:");
	plann.add(0);
	plann.add("project 2 ");
	plann.add("This is the description 2");
	plann.add(200);
	plann.add("project 3 ");
	plann.add("This is the description 3");
	plann.add(300);



	ArrayList<Object> planPro = new ArrayList<Object>();

		 while(j < 4){
			
		 	z=plann.get(i);
		 	planPro.add(z);
			
		 	j++;
		 	i++;			
			}

		System.out.println(planPro.get(0) + " ($" + planPro.get(2) + "): " + planPro.get(1) );
		//planPro.clear();
		j=1;

		if(i < plann.size()-1){
		
		
		displayPlanner();

		 }
		 return(plann);
	}
	
}

	













	