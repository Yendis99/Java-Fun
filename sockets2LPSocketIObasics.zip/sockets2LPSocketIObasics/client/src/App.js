import io from 'socket.io-client';
import React, { useState, useEffect } from 'react';

import './App.css';

function App() {


 const [socket] = useState(() => io("http://localhost:8000"));
  // const socket = io.connect('http://localhost:8000')
  console.log(socket) 

  useEffect(() => {
    console.log('Is this running');
    socket.on('Welcome', data => console.log(data));

    return () => socket.disconnect(true);
  }, );

  return (
    <div className="App">
     <h1>Socket Test</h1>
        <div>Hostname: {socket.io.engine.hostname}</div>
        <div>PingInterval: {socket.io.engine.pingInterval}</div>
        <div>PingTimeout: {socket.io.engine.pingTimeout}</div>
        <div>Emit and say something!</div>
        <div>and all sockets will recieve!</div>
    </div>
  );
}

export default App;
