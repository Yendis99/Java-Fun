package com.srobin.tvshow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TvShowApplicationTests {

	@Test
	void contextLoads() {
	}

}
