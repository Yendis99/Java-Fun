package com.srobin.tvshow.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.Size;


//imports removed for brevity
@Entity
@Table(name="tvshows")
public class TVShowModel {
@Valid	
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 private Long id;
 @Size(max=30, min=1, message="Show Title must be between 1 and 30 characters long!")
 private String title;
 @Size(max=30, min=1, message="Network name must be between 1 and 30 characters long!")
 private String network;
 @Transient
 @Column(updatable=false)
 private Date createdAt;
 private Date updatedAt;
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name ="user_id")
 private User user;
 
 public TVShowModel() {
 }
 
 // other getters and setters removed for brevity
@PrePersist
 protected void onCreate(){
     this.createdAt = new Date();
 } 
 @PreUpdate
 protected void onUpdate(){
     this.updatedAt = new Date();
 	}


 
 
public User getUser() {
	return user;
}

public void setUser(User user) {
	this.user = user;
}

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getNetwork() {
	return network;
}

public void setNetwork(String network) {
	this.network = network;
}


public Date getCreatedAt() {
	return createdAt;
}

public void setCreatedAt(Date createdAt) {
	this.createdAt = createdAt;
}

public Date getUpdatedAt() {
	return updatedAt;
}

public void setUpdatedAt(Date updatedAt) {
	this.updatedAt = updatedAt;
}

}
