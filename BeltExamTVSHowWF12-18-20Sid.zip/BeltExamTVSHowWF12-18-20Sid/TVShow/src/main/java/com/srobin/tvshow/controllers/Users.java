package com.srobin.tvshow.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.srobin.tvshow.models.User;
import com.srobin.tvshow.services.UserService;
import com.srobin.tvshow.validators.UserValidator;

@Controller
public class Users {
	private final UserService userService; 
	
	private final UserValidator userValidator;
 
 //public Users(UserService userService, UserValidator userValidator) {
 public Users(UserService userService, UserValidator userValidator) {
	        this.userService = userService;
	        this.userValidator = userValidator;
	        
	    }
	        
 
 @RequestMapping("/")
 public String login() {
     return "/users/loginPage.jsp";
 }
 
 @RequestMapping("/registration")
 public String registerForm(@ModelAttribute("user") User user) {
     return "/users/registrationPage.jsp";
 }
 
  @RequestMapping("/logout")
 public String logout(HttpSession session) {
     session.invalidate();// invalidate session 
     return "/users/loginPage.jsp";
 	}
 
 @RequestMapping("/index") //This is where you-wanna end up if you've successfully logged in
 public String home(HttpSession session, Model model) {
     Long userId = (Long) session.getAttribute("userId");// get user from session, save them in the model and return the home page
     User u = userService.findUserById(userId);
     model.addAttribute("user", u);
     
     return "redirect:/view";
    
 }
 
 
//DIVIDE
 
 @RequestMapping(value="/registration", method=RequestMethod.POST)
public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
	 userValidator.validate(user,  result);
	 if(result.hasErrors()){
		 // return "loginPage.jsp";
		 return "/users/registrationPage.jsp";
	 } else {
	 User u = userService.registerUser(user);  
	 session.setAttribute("userId", u.getId());
	 session.setAttribute("name", u.getName());
	 return "redirect:/view";
	 } 
 }
 
 
//
//	    @RequestMapping("/createError")
//	    public String flashMessage1(RedirectAttributes redirectAttributes) {
//	        redirectAttributes.addFlashAttribute("error", "Invalid Credentials.    Please try again. ");
//	        return "Null";
//	    }
//	    
//	    @RequestMapping("/regError")
//	    public String flashMessage2(RedirectAttributes redirectAttributes) {
//	       
//	        return "redirect:/registration";
//	    }
	

 


 
 
 @RequestMapping(value="/login", method=RequestMethod.POST)
 public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model, HttpSession session) {
     boolean isAuthenticated = userService.authenticateUser(email, password); // if the user is authenticated, save their user id in session
     if(isAuthenticated){ // else, add error messages and return the login page
    	 User u = userService.findByEmail(email);
    	 session.setAttribute("userId", u.getId());
    	 session.setAttribute("name", u.getName());
     	 return "redirect:/view";
    	
     } else {
    	 model.addAttribute("error", "Invalid Credentials. Please try again.");
    	 return "/users/loginPage.jsp";
    	 
    	 }
  
 	}
 
 


public UserService getUserService() {
	return userService;
	}
 
}
