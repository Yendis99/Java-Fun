package com.srobin.tvshow.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.srobin.tvshow.models.TVShowModel;
import com.srobin.tvshow.services.TVShowService;



@Controller
public class TVShowController {
	
	private final TVShowService tVShowService; 
	
	
	
//	public final TVShowValidator tVShowValidator;
 

	 public TVShowController(TVShowService tVShowService) {
	        this.tVShowService = tVShowService;
	     
	        
	    }

	 @GetMapping("/xshows") //generates a list of book data from the db
	    public String listy(@ModelAttribute("tVShowModel") TVShowModel tVShowModel, Model model) {
	        List<TVShowModel> tVShow = tVShowService.allShows();
	        model.addAttribute("tVShowModel", tVShowModel);
	    //    System.out.println(books);
	        return "/shows.jsp";
	    }
	 
	 
	 
	 @RequestMapping("/view")
	 public String index(@ModelAttribute("tVShowModel") TVShowModel tVShowModel, Model model) {
	        List<TVShowModel> tvshowmodel = tVShowService.allShows();
	        model.addAttribute("tvshowmodel", tvshowmodel);
	     return "/shows.jsp";
	 }
	 
	 
	 @RequestMapping("/new")
	 public String newShow(@ModelAttribute("tTVShowModel")TVShowModel tVShowModel, BindingResult result, HttpSession session) {
	     return "/newShow.jsp";
	 }
	 
	 
	
	 
	    @RequestMapping(value="/create", method=RequestMethod.POST) 
	    public String create(@Valid @ModelAttribute("tVShowModel") TVShowModel tVShowModel, BindingResult result, Model model) { System.out.println(tVShowModel);
	        if (result.hasErrors()) {
	        	model.addAttribute("tVShowModel", tVShowService.allShows());
	            return "redirect:/books";
	        } else {
	          tVShowService.createShow(tVShowModel);
	          return "redirect:/view";
	        }
		}
	 	 
	 

	 
	//Edit a Book
	    @RequestMapping(value="/new/{id}/edit", method=RequestMethod.GET)
	    public String edit(@PathVariable("id") Long id, Model model) {
	    	TVShowModel tVShowModel = tVShowService.findShow(id);
	        model.addAttribute("tVShowModel", tVShowModel);
	        return "/editShow.jsp";
	    }
	    
	    @RequestMapping(value="/new/{id}/update", method=RequestMethod.POST)
	    public String update(@Valid @ModelAttribute("tVShowModel") TVShowModel tVShowModel, BindingResult result, @PathVariable("id") Long id, String title, String network, Model model) {
	       
	    	if (result.hasErrors()) {
	            return "redirect:/view";
	        } else {
	        	
	        	tVShowService.updateShow(tVShowModel.getId(), title, network);
	            return "redirect:/view";
	        }
	    }

	    
	    @RequestMapping(value="/new/{id}/delete", method= {RequestMethod.DELETE, RequestMethod.GET})
	    public String destroy(@PathVariable("id") Long id, Model model) {
	        tVShowService.destroy(id);
	        return "redirect:/view";
	    }
	}


	        