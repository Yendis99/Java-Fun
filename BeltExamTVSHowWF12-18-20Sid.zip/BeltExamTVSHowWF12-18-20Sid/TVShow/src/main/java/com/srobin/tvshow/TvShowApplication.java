package com.srobin.tvshow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TvShowApplication {

	public static void main(String[] args) {
		SpringApplication.run(TvShowApplication.class, args);
	}

}
