package com.srobin.tvshow.services;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.srobin.tvshow.models.TVShowModel;
import com.srobin.tvshow.repos.TVShowRepos;

@Service
public class TVShowService {

	private final TVShowRepos tVShowRepos;
	
	public TVShowService(TVShowRepos tVShowRepos) {
		this.tVShowRepos = tVShowRepos;
	}
	
	
	 // returns all the Shows 
    public List<TVShowModel> allShows() {
        return tVShowRepos.findAll();
    }
    // creates a Show
    public TVShowModel createShow(TVShowModel s) {
        return tVShowRepos.save(s);
        
    }
    // retrieves a Show
    public TVShowModel findShow(Long id) {
        Optional<TVShowModel> optionalTVShowModel = tVShowRepos.findById(id);
        if(optionalTVShowModel.isPresent()) {
            return optionalTVShowModel.get();
        } else {
            return null;
        }
    }
      
    //Update a Show
    public TVShowModel updateShow(Long id, String title, String network) {    
    	TVShowModel t = this.findShow(id);
    	t.setTitle(title);
    	t.setNetwork(network);
    	return tVShowRepos.save(t);
    }
    
    //Delete a Show
    public TVShowModel destroy(Long id){
    	tVShowRepos.deleteById(id);
    return null;
    }
 
    public Integer index(HttpSession session, Model model){ 
        session.setAttribute("count", 0);
        Integer count = (Integer) session.getAttribute("count");
        return count;
    }
    
    
 }

