alert("Welcome to the Date Template");



		window.onload = function()
		{
			document.getElementById("result").innerHTML = Date.now();

			var year = myDate.getFullYear();
			var month = myDate.getMonth() +1;
			var hours = myDate.getHours();
			var mins = myDate.getMinutes();
			var secs = myDate.getSeconds();
			if (Month<10){
				Month = "0" + month;
				}
			var date = mydate.getDate();
			if (date<10){
				date = "0" + date;
			}

			//var formattedDate = year + "/" + month + "/" + date;
			//document.getElementById("result").innerHTML = formattedDate;
		}
