package com.srobin.thecode2;

import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class TheCode2Controller {
	String key = "bushido";
		
	@RequestMapping("/")
	public String index(Model model) {
		
		return "index.jsp";
				
		}

	@RequestMapping(value="call", method=RequestMethod.POST)
	public String tryCode(@RequestParam(value="codecheck") String code) {
		if(code.equals(key)) {
			System.out.println("true");
			return "redirect:/code";
			
			
		} else {
			System.out.println("false");
			return "redirect:/throwErr";
		}
		
	}

		@RequestMapping("/code")
		public String code(Model model) {
			
			return "code.jsp";
					
			
		}
		
		@RequestMapping("/throwErr")
	    public String flashMessages(RedirectAttributes redirectAttributes) {
	        redirectAttributes.addFlashAttribute("error", "You must train harder!");
	        return "redirect:/";
	    }
	}

	


