package com.srobin.thecode2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheCode2Application {

	public static void main(String[] args) {
		SpringApplication.run(TheCode2Application.class, args);
	}

}
