import logo from './logo.svg';
import './App.css';
import UserForm from './components/UserForm';
import RegForm from './components/RegForm';

function App() {
  return (
    <div className="App">
     
     <RegForm/>
    <clickHandler />
    

    </div>
  );
}

export default App;
