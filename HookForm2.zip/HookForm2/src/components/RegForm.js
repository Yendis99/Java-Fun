
import React, { useState } from 'react';

const RegForm = (props) => {
	const [firstName, setFirstname] = useState("");
	const [lastName, setLastname] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword]= useState("");

	const regUser = (e) => {
		(e).preventDefault();
		const newUser = {firstName, lastName, email, password};
		console.log("Welcome " + newUser); 
	};

	

	return (
		<form onSubmit = { regUser }>
			<div className = "fldfrm">
				<div className="input">
					<label>First Name: </label>
					<input type="text" onChange={ (e) => setFirstname(e.target.value) } value={firstName} />
				</div>
				<div className="input">
					<label>Last Name:</label>
					<input type="text" onChange={ (e) => setLastname(e.target.value) } value={lastName} />
				</div>
				<div className="input">
					<label>Email: </label>
					<input type="text" onChange={ (e) => setEmail(e.target.value) } value={email} />
				</div>
				<div className="input">
					<label>Password: </label>
					<input type="text" onChange={ (e) => setPassword(e.target.value) } value={password} />
				</div>
			
				<input type="submit" value="Register" />
			


			<div className="reginfo">
			 <h3> Your Registration Information </h3>
			 <p> First Name: { firstName } </p>
			 <p> Last Name: { lastName } </p>
			 <p> Email: { email } </p>
			 </div>

			 </div>


				
		</form>

		
		);

}

export default RegForm;