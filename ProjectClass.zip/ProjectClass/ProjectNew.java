public class ProjectNew{
	private String name;
	private String description; //these are variables
	private double number;

	
	public ProjectNew(){
		
	
	}




	
	public void setName(String name){ //setters - a method that allow the test program to set the name
		this.name=name;
	}
	public void setDescription(String description){// set desc.
		this.description=description;
	}
	public void setNumber(double number){ //set cost number.
		this.number=number;
	}
	public String getName(){ //getters - a method that allows the test program to get the name
		return this.name;
	}
	public String getDescription(){// get desc.
		return this.description;
	}
	public double getNumber(){// get cost number.
		return this.number;
	}



	


	public String elivatorPitch(String input1, String input2, double input3){
		setName(input1);
		setDescription(input2);
		setNumber(input3);
		return (getName() + ":" + getDescription() + "($" + getNumber() + ")");
	}


	public String project(){
		return("enter a project name and description - Use b.elivatorPitch to include a cost");
	}
	public String project(String name){
		setName(name);
		return(getName());
	}
	public String project(String name, String description){
		setName(name);
		setDescription(description);
		return(getName()+ "  " + getDescription());
	}

}