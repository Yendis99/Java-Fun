public class ProjectNewTest{ // Creates the test class (always needed)
	public static void main(String[] arg){  //Java starting point (always needed)





		
		ProjectNew p = new ProjectNew();  //calling and overloaded ProjectNew function with the name param only

		//System.out.println(p.project());
		//System.out.println(p.project("myfavproject"));
		//System.out.println(p.project("myfavproject", "Biggest project Ever"));

		// System.out.println(p.getName());
		// System.out.println(p.getDescription());
		// System.out.println(p.getNumber());

		System.out.println(p.elivatorPitch("pro1", "best project", 34000.01));
		 // This calls the elivatorPitch method and passes two variables - output is those variables seperated by a colon

	

		


		


		
		}
	}
