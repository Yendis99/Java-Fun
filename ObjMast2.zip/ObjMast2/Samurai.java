public class Samurai extends Human{
	static int noOfBrothers = 0;
	{
		noOfBrothers +=1;
	}

	public Samurai(){
		super();
		setHealth(health+=100);
	 
		}

	public int meDitate(int rx){
		setHealth(health += rx/2);
		return getHealth();
	}
	
	public int howMany(){
		return(Samurai.noOfBrothers);
	}

}



// dfault health 200
// meth deathBlow(Human) kills other human and reduces Samurai health by 50%
// meth meditate() heals Sam += 50% of current health
// meth howMany() returns current total number of Sams