public class Wizard extends Human{

	public Wizard(){
		super();
		setIntelligence(intelligence+=5);
		setHealth(health-=50);
		// System.out.println("wizard intelligence is: " + getIntelligence());
		// System.out.println("wizard healthe is: " + getHealth());

	}

	// public int healHuman(String x){
	// 	System.out.println(x);
	// 	// if(x == s){
	
	// 	// System.out.println("Wizard throws a healing spell at you");
	// 	// 	s(8);
	// 	return health;


		
	

	// }
}


	//method heal(Human) --> others health +=8
	//method fireball(Human) --> others health -=8*3













	// 	public int displayEnergy(){
	// 	System.out.println("Your energy level is at:" + this.energyLevel);
	// 	return this.energyLevel;
	// } 











// WE ARE GOING TO USE SUPER TO ACCESS THAT ATTRIBUTES IN HUMAN TO SET THE DIFFERENT PRIVATE ATTRIBUTES
//I.E. @ 27:32 of - https://vimeo.com/463220697/9161f7dfee has - public Rectangle(int height, int  length, int x, int y)
//                                             and then calls -> super(x, y);
//                                             to directly call the parent shape which was extended to it                          

//* dfault health to 50

//* dfault intelligence to 8

// method heal(Human) --> others health +=8

// meth fireball(Human) --> others health -= 8 * 3