


public class HumanTest{
	public static void main(String[] args){

		
		Human a = new Human();
		Human b = new Human();
		Wizard w = new Wizard();
		Ninja n = new Ninja();
		Samurai s = new Samurai();



		
		// w.healHuman(s);

		System.out.println("key: strength, stealth, intelligence, health");
		
		System.out.println("Instantiated Human a"); //instantiated human with base attribs
		System.out.println(a.getStrength());
		System.out.println(a.getStealth());
		System.out.println(a.getIntelligence());
		System.out.println(a.getHealth());

		System.out.println("Instantiated Human b"); //instantiated human with base attribs
		System.out.println(b.getStrength());
		System.out.println(b.getStealth());
		System.out.println(b.getIntelligence());
		System.out.println(b.getHealth());


		System.out.println("Instantiated Wizard w"); //instatiated wizard with base and enhance attribs
		System.out.println(w.getStrength());
		System.out.println(w.getStealth());
		System.out.println(w.getIntelligence());
		System.out.println(w.getHealth());

		System.out.println("Instantiated Ninja n");//instatiatec ninga with base and enhance attribs
		System.out.println(n.getStrength());
		System.out.println(n.getStealth());
		System.out.println(n.getIntelligence());
		System.out.println(n.getHealth());

		System.out.println("Instantiated Samurai s");//instantiated Samaruai with base and enhance attribs
		System.out.println(s.getStrength());
		System.out.println(s.getStealth());
		System.out.println(s.getIntelligence());
		System.out.println(s.getHealth());


		System.out.println("ninja inflicts stealHuman attack on wizard then on samurai - decs opponent's health by his stealth(10)");
		System.out.println(n.stealHuman(w.getHealth()));//ninja uses stealHuman attack on wizard  decr. health by nins stealth (10)
		System.out.println(n.stealHuman(s.getHealth()));//ninja uses stealHuman attack on samurai  decr. health by nins stealth (10)

		System.out.println("ninja uses runAway technique - decs nins health by 10"); //using ninja's runAway technique 
		System.out.println(n.getHealth());
		System.out.println(n.runAway());

		System.out.println("Samurai uses meditate to heal - incs health to 50% current value");
		System.out.println(s.getHealth());
		System.out.println(s.meDitate(s.getHealth()));

		System.out.println("Samurai uses howMany technique - show how many Samurai exist");
		System.out.println(s.howMany());
		System.out.println("2 new Samurai are instantiated - then we call the Samurai howMany technique");
		Samurai s2 = new Samurai();
		Samurai s3 = new Samurai();
		System.out.println(s.howMany());

		System.out.println("Samurai uses deathBlow technique - kills who it hits and decreases Samuria's health by 50%");
		System.out.println(s.getHealth() + "s health");
		System.out.println(w.getHealth() + "w health");
		System.out.println(s.deathBlow(w.getHealth()) + "   aww.. the wizard layed a goose egg");
	

	}
}