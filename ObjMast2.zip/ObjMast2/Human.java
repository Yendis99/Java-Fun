public class Human {
	protected int strength;
	protected int stealth;
	protected int intelligence;
	protected int health;
	
	public Human(){
		this.strength=3;
		this.stealth=3;
		this.intelligence=3;
		this.health=100;
	}


	public int getStrength(){
		return this.strength;
	}
	public void setStrength(int str){
		this.strength=strength;
	}

	public int getStealth(){
		return this.stealth;
	}
	public void setStealth(int ste){
		this.stealth=stealth;
	}

	public int getIntelligence(){
		return this.intelligence;
	}
	public void setIntelligence(int i){
		this.intelligence=intelligence;
	}

	public int getHealth(){
		return this.health;
	}
	public void setHealth(int h){
		this.health=health;
	}


	public int attackHuman(){
		health -= 3;
		System.out.println("You've been attacked!, Your health is now:" + this.health);
		return this.health;
	}

	public int stealHuman(int hit){
		hit  -= this.stealth;
		System.out.println("You've just got stolt on! Your health is now: " + hit);
		return (hit);
		}
	

	public int deathBlow(int hit){
		hit  -= hit;
		setHealth(health -= health/2);
		System.out.println("DEATHBLOW!..... SEE ya fool - Sami you have: " + this.health + " health left.");
		return (hit);
		}

}


