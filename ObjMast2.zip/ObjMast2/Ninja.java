public class Ninja extends Human{

	public Ninja(){
		super();
		setStealth(stealth+=7);
		setHealth(health-=50);
	

	}

	public int runAway(){
		setHealth(health-=10);
		return getHealth();
	}



}


// dfault stealth = 10

// meth steal(Human) == others health -= nins stealth and adds that amount to nins health
// method runAway() == decrease nins health by 10




