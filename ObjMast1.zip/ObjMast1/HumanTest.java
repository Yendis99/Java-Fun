


public class HumanTest{
	public static void main(String[] args){

		
		Human a = new Human();
		Human b = new Human();
		// Wizard w = new Wizard();
		// Ninja n = new Ninja();
		// Samurai s = new Samurai();

		
		// w.healHuman(s);
		
		System.out.println("Instantiated Human a");
		System.out.println(a.getStrength());
		System.out.println(a.getStealth());
		System.out.println(a.getIntelligence());
		System.out.println(a.getHealth());

		System.out.println("Instantiated Human b");
		System.out.println(b.getStrength());
		System.out.println(b.getStealth());
		System.out.println(b.getIntelligence());
		System.out.println(b.getHealth());


	}
}