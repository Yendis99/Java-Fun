public class Human {
	protected int strength;
	protected int stealth;
	protected int intelligence;
	protected int health;
	
	public Human(){
		this.strength=3;
		this.stealth=3;
		this.intelligence=3;
		this.health=100;
	}


	public int getStrength(){
		return this.strength;
	}
	public void setStrength(int str){
		this.strength=strength;
	}

	public int getStealth(){
		return this.stealth;
	}
	public void setStealth(int ste){
		this.stealth=stealth;
	}

	public int getIntelligence(){
		return this.intelligence;
	}
	public void setIntelligence(int i){
		this.intelligence=intelligence;
	}

	public int getHealth(){
		return this.health;
	}
	public void setHealth(int h){
		this.health=health;
	}


	public int attackHuman(){
		health -= 3;
		System.out.println("You've been attacked!, You health is now:" + this.health);
		return this.health;

	}

}


