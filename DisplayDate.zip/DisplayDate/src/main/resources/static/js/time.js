alert("Welcome to the Time Template!");

