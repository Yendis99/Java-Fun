package com.srobin.displaydate;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpSession;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Controller
//@RestController
@SpringBootApplication

public class DisplayDateApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisplayDateApplication.class, args);
	}

//	@RequestMapping("/")
//	//public String dash()
//	 public String dash(Model model) {
//		return "dash.html";		
//	}
	
	@RequestMapping("/time")
	//public String dash()
	 public String time(Model model) {
		return "time.html";		
	}
	
	@RequestMapping("/date")
	//public String dash()
	 public String date(Model model) {
		return "date.html";		
	}
	
	
	
//	@RequestMapping("/dash")
//	public String dash() {
//		return "index.html";
//	}
//	
//	@RequestMapping("/date")
//	public String date() {
//		return "date.html;";
//	}
//	@RequestMapping("/time")
//	public String time() {
//		return "time.html";
//	}




//DateTimeFormatter dxfo = DateTimeFormatter.ofPattern("EE, 'the' d 'of' MMMM, YYYY");
//        LocalDateTime now = LocalDateTime.now();
//        System.out.println(dxfo.format(now));
//        model.addAttribute("date", .format(now) );
//        return "date.jsp";




	  
//	  @RequestMapping("/bot")
//		public String index(@RequestParam(value="name",required=false)String searchQuery) {
//			if(searchQuery == null) {
//				return "Hello Human!";
//			}
//			else {
//				return "Hello " + searchQuery;
//			
//			}
//	  }
//	  
//	  @RequestMapping("/page")
//	    public String index(Model model) {
//	        model.addAttribute("dojoName", "Burbank");
//	        return "index.jsp";
//	    }
//	 
	  
	  
	
}


