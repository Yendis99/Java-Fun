import java.lang.Math;
public class PythagMath{
	public void calcHypotenuse(double legA, double legB){
		double sr1 = Math.sqrt((double)legA);
		//System.out.print(sr1);
		double sr2 = Math.sqrt((double)legB);
		//System.out.print(sr2);
		double ans = sr1 + sr2;
		System.out.println(ans);
	}
}