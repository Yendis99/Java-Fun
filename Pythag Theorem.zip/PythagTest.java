public class PythagTest{
	public static void main(String[] args){
		PythagMath PyMath = new PythagMath();
		PyMath.calcHypotenuse((double)7, (double)8);
	}
}


