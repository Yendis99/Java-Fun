import java.util.Random;
import java.io.*; 
import java.lang.*; 
import java.util.*;

public interface BankCreateAccount{
	public  int x = 0;
	String str = "";
	


	static String getAccountNum(){

		ArrayList<String> AcctNum = new ArrayList<String>();

		 for(int i = 0; i < 10; i++){
		 	int x = (int)(Math.random() * 9);
	
		    AcctNum.add(String.valueOf(x));
	    
		 } 
		 StringBuffer sb = new StringBuffer();
	      
	      for (String s : AcctNum) {
	         sb.append(s);
	         sb.append("");
	      }
	      String str = sb.toString();


		return(str);	
		 }	
		

	}

