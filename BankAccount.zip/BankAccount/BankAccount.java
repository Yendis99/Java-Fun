public class BankAccount{

	private String accountNumber;
	private double checkingBalance;
	private double savingsBalance;

	private int numberOfAccounts;
	private double accountsTotalBalance;

	public void BankAccount(){
		this.accountNumber = "";
		this.checkingBalance = 0.00;
		this.savingsBalance = 0.00;
		this.numberOfAccounts = 0;
		this.accountsTotalBalance = 0;

	}




	//saving and checkings deposit methods
	public double savingsDeposit(double sdepo){

		this.savingsBalance += sdepo;
		this.accountsTotalBalance += sdepo;

		return this.savingsBalance;

	}
	public double checkingDeposit(double cdepo){

		 checkingBalance += cdepo;
		 accountsTotalBalance += cdepo;

		 return this.checkingBalance;
	}


	//saving and checkings withdrawal methods
	public double savingsWithdrawal(double sdepo){

		if(this.savingsBalance-sdepo >= 0){
			savingsBalance -= sdepo;
			accountsTotalBalance -= sdepo;



		} else {
			System.out.println("There is not enough cash in you savings account to allow your withdrawal.");
		}return savingsBalance;

	}
	public double checkingWithdrawal(double cdepo){

		 if(this.checkingBalance-cdepo >= 0){
		 	checkingBalance -= cdepo;
		 	accountsTotalBalance -= cdepo;

		 	

		 } else { System.out.println("there is not enough cash in you checkings account to make a withdrawal.");
		} return checkingBalance;
	}




	//Good boy Ubu Gets and Sets!
	private void setAccountNumber(){
		this.accountNumber = BankCreateAccount.getAccountNum();
	

	}
	
	private String getAccountNumber(){
		return this.accountNumber;
	}

	public void setCheckingBalance(double cbal){
		this.checkingBalance = checkingBalance+=cbal;
	}

	public double getCheckingBalance(){
		return this.checkingBalance;
	}

	public void setSavingsBalance(double sbal){
		this.savingsBalance = savingsBalance+=sbal;
	}

	public double getSavingsBalance(){
		return this.savingsBalance;
	}

	public void setNumberOfAccounts(int nofa){
		this.numberOfAccounts = numberOfAccounts+=nofa;
	}

	public int getNumberOfAccounts(){
		return this.numberOfAccounts;
	}
	
	public void setAccountsTotalBalance(double totbalns){
		this.accountsTotalBalance = accountsTotalBalance+=totbalns;
	}

	public double getAccountsTotalBalance(){
		return this.accountsTotalBalance;
	}

}