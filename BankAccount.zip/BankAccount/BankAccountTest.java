public class BankAccountTest extends BankAccount{
	public static void main(String[] args){

			
	 	 String z = "";

	  	BankAccount b = new BankAccount();


		//Created a interface to provide the 10 dig random account number to experience interface some
	  	System.out.println("creating rand 10 char account nums"); 
	  	z=BankCreateAccount.getAccountNum();
		System.out.println(z.toString());
		System.out.println("account number gen " + z);

		//savingsDeposit method setting and getting
		System.out.println("making savings deposits"); 
		System.out.println(b.getSavingsBalance()); 
		b.savingsDeposit(100);
		System.out.println(b.getSavingsBalance());
		b.savingsDeposit(10);
		System.out.println(b.getSavingsBalance());
		b.savingsDeposit(50);
		System.out.println(b.getSavingsBalance());

		//checkingDeposit method setting and getting
		System.out.println("making checking deposits"); 
		System.out.println(b.getCheckingBalance()); 
		b.checkingDeposit(300);
		System.out.println(b.getCheckingBalance());
		b.checkingDeposit(170);
		System.out.println(b.getCheckingBalance());
		b.checkingDeposit(444);
		System.out.println(b.getCheckingBalance());


		//savingsWithdrawals method setting and getting
		System.out.println("making savings withdrawals"); 
		System.out.println(b.getSavingsBalance()); 
		b.savingsWithdrawal(100);
		System.out.println(b.getSavingsBalance());
		b.savingsWithdrawal(10);
		System.out.println(b.getSavingsBalance());
		b.savingsWithdrawal(50);
		System.out.println(b.getSavingsBalance());

		//checkingWithdrawal method setting and getting
		System.out.println("making checking withdrawals"); 
		System.out.println(b.getCheckingBalance()); 
		b.checkingWithdrawal(300);
		System.out.println(b.getCheckingBalance());
		b.checkingWithdrawal(170);
		System.out.println(b.getCheckingBalance());
		b.checkingWithdrawal(444);
		System.out.println(b.getCheckingBalance());

		//setting the number of accounts / set & get
		System.out.println("setting the number of accounts");
		System.out.println(b.getNumberOfAccounts());
		b.setNumberOfAccounts(9);
		System.out.println(b.getNumberOfAccounts());

		//get combined account total balance
		System.out.println("getting combined account totals");
		System.out.println("Savings:");
		b.savingsDeposit(100);
		System.out.println(b.getSavingsBalance()); 
		System.out.println("Checking:");
		b.checkingDeposit(300);		
		System.out.println(b.getCheckingBalance()); 

		System.out.println("Total accounts");
		System.out.println(b.getAccountsTotalBalance());

		System.out.println("Set Total accounts to 1000");
		b.setAccountsTotalBalance(1000);
		System.out.println(b.getAccountsTotalBalance());
	


		











	}
}