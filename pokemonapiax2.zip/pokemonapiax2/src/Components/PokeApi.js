import React, { useState, useEffect } from 'react';
import axios from 'axios';
import App from '../App';

const PokeApi =({pokemons, myProp}) => { 
   
   
 
    return (
        <div>

            <a>{myProp}</a>
           
            {pokemons.length > 0 && pokemons.map((poke, index)=>{
                return (<div key={index}>{poke.name}</div>)
            })}
     </div>
    );
}
export default PokeApi;

