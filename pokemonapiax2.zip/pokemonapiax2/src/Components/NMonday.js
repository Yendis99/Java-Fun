



  const NMonday = new Promise( (resolve, reject) => {
        if(new Date().getDay() !== 5) {
            resolve("Good, it's not Monday!");
        } else {
            reject("Someone has a case of the Mondays!");
        }
    });
    NMonday
        .then( res => console.log(res) )
        .catch( err => console.log(err) ); 

    
    export default NMonday;
