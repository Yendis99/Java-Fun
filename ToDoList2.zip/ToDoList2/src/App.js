import './App.css';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
//import Tabs from 'react-bootstrap/Tabs'
//import Tab from 'react-bootstrap/Tab'
// import TabContainer from 'react-bootstrap/TabContainer'
import { Container, Row, Col, Button, Alert, Breadcrumb, Card, Form } from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'

import React, { useState, useEffect, State, Component } from 'react';
import { render } from '@testing-library/react';
import axios from 'axios';
import { Router, Link, navigate, Switch } from '@reach/router';



class App extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            currTTDItem: null,
            TTDList:[],
            StrikeList:[]
        };
    }

    setCurrTTDItem=TTDItem => {
        this.setState({
            currTTDItem: TTDItem
        
        });
    };

    storeTTDListItem = TTDItem => {
        this.setState({
            TTDList: [...this.state.TTDList, TTDItem]
        });
    }

    strike = event => {
        const element = event.target;
        element.classList.toggle("strike");
    };

    render(){
        return(
            <div className="frm">
                <h2>To Do</h2>
                <label>Add To Do:</label>
                <input size="50" onChange={event => this.setCurrTTDItem(event.target.value)}></input>
                <button  onClick = {() => this.storeTTDListItem(this.state.currTTDItem)}> <p>Click to Add</p>
                </button>
                <div>
                    <p>To Do List</p>
                    {this.state.TTDList.map((item, index) => {
                        return(
                            <p onClick={this.strike} key={index}> {item}{" "}</p>
                        );
                    })}
                </div>
            </div>
        );
    }
}

export default App;