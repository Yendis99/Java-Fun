import '../App.css'; 
import React, { useState, Component } from 'react';
import { render } from '@testing-library/react'; 

const Strike = ({thn, dnn}) => {
console.log("did");
console.log(thn);
console.log(dnn);


    return (
<>
   
        {thn.map((thn, dnn) => (
        <div className = "strike" >
              {thn}
        </div>
    



     ))}

</>


    )



}

export default Strike;
