import React, {useState, useEffect} from 'react'; //lesson add
import io from 'socket.io-client';  //lesson add
import TextField from '@material-ui/core/TextField'
import './App.css';
import { Router } from '@reach/router';
//import Talk from './views/Talk';


const socket = io.connect('http://localhost:4000')

{/* <Router>
    <Talk path = "/talk" />
</Router> */}

function App() {
  const [state, setState] = useState({message: '', name: ''})
  const [chat, setChat] = useState([])

  useEffect(() => {
    socket.on('message', ({ name, message }) => {
      setChat([...chat, { name, message }])
    })
  });

  const onTextChange = e => {
    setState({...state, [e.target.name]: e.target.value})
  }  

  const onMessageSubmit = e => {
    e.preventDefault()
    const {name, message} = state
    socket.emit('message', {name, message})
    setState({message: '', name })
  }

  const renderChat = () => {
    return chat.map(({name, message}, index) => (
      <div key={index}>
        <h3>{name}: <span>{message}</span></h3>
      </div>
    ))
  }
  
  return (
    <div className="App">
      <form onSubmit = {onMessageSubmit} >
        <h1>Messanger</h1>
          <div className = "namefld">
            <TextField
              name="name"
              onChange={e => onTextChange(e)}
              value={state.name}
              label="Name"
              />
          </div>
          <div>
          <TextField
              name="message"
              onChange={e => onTextChange(e)}
              value={state.message}
              id="outlined-multiline-static" //meterail ui stuff
              variant="outlined" //meterail ui stuff
              label="Message"
              />
          </div>
          <button>Send Message</button>
      </form>
      <div className="render-chat">
        <h1>Chat Log</h1>
        {renderChat()}

      </div>
     </div>
  );
}

export default App;
