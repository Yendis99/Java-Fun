
import React, { useState } from 'react'; 
const RegForm = (props) => {
	const [firstName, setFirstname] = useState("");
	const [lastName, setLastname] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword]= useState("");
	const [confpass, setConfpass]= useState("");
	const [hasBeenSubmitted, SetHasBeenSubmitted] = useState(false);

	const regUser = (e) => {
		(e).preventDefault();
		const newUser = {firstName, lastName, email, password, confpass};
		SetHasBeenSubmitted(true)
		
	 };

	return (

		<div className = "frame">

		{hasBeenSubmitted ? <h3>Thank you for submitting the form!</h3> : <h3>Welcome, please submit the form. </h3>}

		<form onSubmit = {regUser}> 
	
				<div className="input">
					<label>First Name: </label>
					<input type="text" onChange={ (e) => setFirstname(e.target.value) } value={firstName} />
					{firstName.length >=2  ? "" : <p style={{color:'yellow'}}>Must be at least 2 characters long.  </p>}
				</div>
				
				<div className="input">
					<label>Last Name:</label>
					<input type="text" onChange={ (e) => setLastname(e.target.value) } value={lastName} />
					{lastName.length >= 2 ? "" : <p style={{color:'yellow'}}>Must be at least 2 characters long.  </p>}
				</div>
				<div className="input">
					<label>Email: </label>
					<input type="text" onChange={ (e) => setEmail(e.target.value) } value={email} />
					{email.length >=5 ? "" : <p style={{color:'yellow'}}>Must be at least 5 characters long.  </p>}
				</div>
				<div className="input">
					<label>Password: </label>
					<input type="text" onChange={ (e) => setPassword(e.target.value) } value={password} />
					{password.length >=8 ? "" : <p style={{color:'yellow'}}>Must be at least 8 characters long.  </p>}
				</div>

				<div className="input">
					<label>Conf. Password: </label>
					<input type="text" onChange={ (e) => setConfpass(e.target.value) } value={confpass} />
					{confpass.length >=8 ? "" : <p style={{color:'yellow'}}>Must be at least 8 characters long.  </p>}
				</div>

				<input className="clkr"   type="submit" value="Register" />
		
			<div className="reginfo">
			 <h3> Your Registration Information </h3>
			 <p> First Name: { firstName } </p>
			 <p> Last Name: { lastName } </p>
			 <p> Email: { email } </p>
			 </div>
			 	</form>
				 
			 </div>
	
		);
		
	}


export default RegForm;