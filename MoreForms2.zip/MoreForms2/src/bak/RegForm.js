
import React, { useState } from 'react';

const RegForm = (props) => {
	const [firstName, setFirstname] = useState("");
	const [lastName, setLastname] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword]= useState("");
	const [hasBeenSubmitted, SetHasBeenSubmitted] = useState(false);
	const [fErr, setFErr] = useState(false);

	const regUser = (e) => {
		(e).preventDefault();

		const newUser = {firstName, lastName, email, password};
		console.log("Welcome " + newUser.firstName); 
		SetHasBeenSubmitted(true);
		setFErr(true);

	
	};

	const formMessage = () => { //NOT USING TRYING TERNARY
		if( hasBeenSubmitted ) {
			return "Thank you for submitting the form!";
		} else {
			return "Welcome, please submit the form";
		}	
	};

	const flds = (e) => {
		if( !firstName || !lastName || !email || password){
			return "Please complete all of the fields on the form.";
			
			}
			
		}
	

	

	

	return (
		<form onSubmit = { regUser }> 
			
		{
        hasBeenSubmitted ? 
        <h3>Thank you for submitting the form!</h3> :
        <h3>Welcome, please submit the form.</h3> 
      
   		 }

   		 { 
   		 	 firstName ?
				<p style={{color:'red'}}>"HELLO" </p> : ''
   		 }



			<div className = "fldfrm">
				<div className="input">
					<label>First Name: </label>
					<input type="text" onChange={ (e) => setFirstname(e.target.value) } value={firstName} />
				</div>
				<div className="input">
					<label>Last Name:</label>
					<input type="text" onChange={ (e) => setLastname(e.target.value) } value={lastName} />
				</div>
				<div className="input">
					<label>Email: </label>
					<input type="text" onChange={ (e) => setEmail(e.target.value) } value={email} />
				</div>
				<div className="input">
					<label>Password: </label>
					<input type="text" onChange={ (e) => setPassword(e.target.value) } value={password} />
				</div>
				<input type="submit" value="Register" />
			</div>


			<div className="reginfo">
			 <h3> Your Registration Information </h3>
			 <p> First Name: { firstName } </p>
			 <p> Last Name: { lastName } </p>
			 <p> Email: { email } </p>
			 </div>


				
		</form>
		);

};

export default RegForm;