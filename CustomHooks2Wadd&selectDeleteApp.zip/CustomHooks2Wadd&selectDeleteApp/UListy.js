import { useState } from 'react';

export default (initialList = []) => {
    const [list, setList] = useState(initialList);
  

    
    function add(str) {

        if(str != ""){
        setList([...list, str]);

        }
    }

    

    function remove(str) {

      
        console.log(str.index);
       
        if(str.index != undefined) { setList([
           
           ...list.slice(0, str.index),
           ...list.slice(str.index + 1),

          //...list.slice(0, -1) //this remove the last item only

         // ...list.slice(+1) //this removes the 1st item only
        ])};
    }

return {
    list,
    add,
    remove
    };

};

{/* <li key={i} onClick={this.handleClick.bind(this, i)} style={s}>
<img src="images/joy.png"/>
</li> */}

