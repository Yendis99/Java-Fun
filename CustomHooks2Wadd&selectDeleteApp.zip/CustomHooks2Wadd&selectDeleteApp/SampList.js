import React, { useState } from 'react';

import UListy from './UListy';

export default (props) => {
    const [val, setVal] = useState('');
    const [rval, setRval] = useState('yep');
    const { list, add, remove } = UListy(["Banana", "Orange", "Lemon", "Apple", "Mango"]);

    //['first', 'second', 'third', 'fourth', 'fith']


    const handleSubmitA = (e) => {
        console.log({val});
        e.preventDefault();

        add(val);

        setVal('');
      
    }

    const handleSubmitB = (e) => {

        console.log(rval.index);
        console.log({rval});
        e.preventDefault();

        remove(rval);
       
        setRval('');

        
    }

    return (
        <>
           

           <div>
            { list.map(( item, index ) => {
                return( <p key={index} onClick={ (e) => setRval({index})}
                value={rval}
            
                 >
                        {item} {index} </p> )
            })}
              

            </div>

            <input
                onChange={ (e) => setVal(e.target.value)}
                value={val}

              
             
            />
            <button onClick={handleSubmitA}>Add</button>

{/* Add in UListy/function remove ;   ...list.slice(0, -1) to UListy remove function to remove last item */}
{/* Add in UListy/function remove ;   ...list.slice(+1) to UListy remove function to first item */}
{/* use the following in UListy/function remove to select item and remove 

 if(str.index != undefined) { setList([
           
           ...list.slice(0, str.index),
           ...list.slice(str.index + 1),

        ])}; */}
        
            <button onClick={handleSubmitB}>Remove item</button> 









        

        </>
    );
}; 

