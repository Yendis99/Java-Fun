import React, { useState } from 'react'
import axios from 'axios';
export default () => {
    //keep track of what is being typed via useState hook
    const [title, setTitle] = useState(""); 
    const [price, setPrice] = useState("");
    const[desc, setDesc] = useState("");
    //handler when the form is submitted
    const onSubmitHandler = e => {
        //prevent default behavior of the submit
        e.preventDefault();
        //make a post request to create a new product
        axios.post("http://localhost:8000/api/prod/new",{
            title,
            price,
            desc
        })
            .then(res=>console.log(res))
            .catch(err=>console.log(err))
    }
    //onChange to update firstName and lastName
    return (
        <>
        <h1>Product Manager</h1>
        <form onSubmit={onSubmitHandler}>
            <div className="ini">
            <p>
                <label>Title: </label>
                <input type="text" onChange = {(e)=>setTitle(e.target.value)}/>
            </p>
            </div>
            <div className="ini">
            <p>  
                <label>Price: </label>
                <input type="number" onChange = {(e)=>setPrice(e.target.value)}/>
            </p> 
            </div>
            <div className="ini">
            <p>
                <label>Desc.: </label>
                <input type="text" onChange = {(e)=>setDesc(e.target.value)}/>
            </p>
            </div>
            <button type="submit">Add Product</button>
        </form>
        </>
    )
}

