const ProductController = require('../controllers/product.controller');
module.exports = function(app){
    app.get('/api/prod/list', ProductController.index);
    app.post('/api/prod/new', ProductController.createProduct); 


    
    
    
    

}
