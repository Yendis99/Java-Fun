class Pythagorean{
	public static void main(String[] args){
	
		PythagoreanMath Mathy = new PythagoreanMath();
		Mathy.doMath((double)7, (double) 8);

		

	}
}
