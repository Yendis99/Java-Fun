import java.lang.Math; 
class PythagoreanMath{
	public void doMath(double arg1, Double arg2){
		System.out.println(Math.sqrt(arg1));
		System.out.println(Math.sqrt(arg2));
		double Ans = Math.sqrt(arg1) + Math.sqrt(arg2);
		System.out.println(Ans);
	
		

	}

	

}